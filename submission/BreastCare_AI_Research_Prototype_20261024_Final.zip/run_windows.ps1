$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "BreastCare AI - Phase 2.2 local launcher" -ForegroundColor Cyan
if (-not (Get-Command python -ErrorAction SilentlyContinue)) { throw "Python 3.11/3.12 not found. Install Python and retry." }
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw "Node.js 20 LTS or newer not found. Install Node.js and retry." }
if (-not (Test-Path "backend/.venv/Scripts/python.exe")) { python -m venv backend/.venv }
& "backend/.venv/Scripts/python.exe" -m pip install -r backend/requirements.txt
if (-not (Test-Path "frontend/node_modules")) { Push-Location frontend; npm install; Pop-Location }
Start-Process powershell -ArgumentList "-NoExit", "-Command", "Set-Location '$PSScriptRoot/backend'; & '$PSScriptRoot/backend/.venv/Scripts/python.exe' -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000"
Start-Process powershell -ArgumentList "-NoExit", "-Command", "Set-Location '$PSScriptRoot/frontend'; npm run dev -- --host 127.0.0.1"
Write-Host "Frontend: http://localhost:5173" -ForegroundColor Green
Write-Host "API docs: http://127.0.0.1:8000/docs" -ForegroundColor Green
