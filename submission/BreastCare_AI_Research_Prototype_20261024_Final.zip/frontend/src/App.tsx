import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { Link, NavLink, Route, Routes, useLocation, useNavigate, useParams } from "react-router-dom";
import {
  Activity, ArrowDownRight, ArrowRight, BrainCircuit, CheckCircle2,
  CircleHelp, ClipboardList, CloudDownload, Database, FileText, FlaskConical,
  HeartPulse, Image as ImageIcon, LayoutDashboard, LockKeyhole, Menu,
  Microscope, Scan, Search, Settings, ShieldCheck, Table2, Upload, UserRound, X, Zap,
} from "lucide-react";
import { API_BASE, analyzeCsv, extractReport, getHealth, getModules, inspectImaging, predictHistopathology, type CsvAnalysisResult, type HistopathologyResult, type ImagingInspectionResult, type ReportExtractionResult } from "./api";
import type { ResearchModule } from "./types";

const iconMap: Record<string, typeof Microscope> = {
  Microscope, Scan, Activity, Image: ImageIcon, FileText, Table2,
};

function useModules() {
  const [modules, setModules] = useState<ResearchModule[]>([]);
  useEffect(() => {
    getModules().then(setModules).catch(() => setModules([
      { id: "histopathology", title: "Histopathology", subtitle: "Tissue image analysis", description: "Optional BreaKHis ResNet-18 research model; not for diagnosis or clinical use.", icon: "Microscope", input_types: ["PNG", "JPG", "TIFF"], status: "interface_ready_model_missing", accent: "teal" },
      { id: "ct", title: "CT Scan", subtitle: "Computed tomography", description: "Single-image and DICOM-header review only. No CT prediction model is installed.", icon: "Scan", input_types: ["DICOM", "PNG", "TIFF"], status: "metadata_review_available_model_missing", accent: "blue" },
      { id: "mri", title: "MRI Analysis", subtitle: "Magnetic resonance imaging", description: "Single-image and DICOM-header review only. No MRI prediction model is installed.", icon: "Activity", input_types: ["DICOM", "PNG", "TIFF"], status: "metadata_review_available_model_missing", accent: "purple" },
      { id: "xray", title: "X-ray & Mammography", subtitle: "Radiology image analysis", description: "Single-image and DICOM-header review only. No radiology prediction model is installed.", icon: "Image", input_types: ["DICOM", "PNG", "JPG", "TIFF"], status: "metadata_review_available_model_missing", accent: "orange" },
      { id: "reports", title: "Doctor Reports", subtitle: "Prescription and report extraction", description: "Extract text from reports for human review. No medical interpretation is performed.", icon: "FileText", input_types: ["PDF", "PNG", "JPG"], status: "interface_ready_text_extraction", accent: "green" },
      { id: "csv", title: "CSV Analysis", subtitle: "Tabular data exploration", description: "Explore structure, missing values, and descriptive statistics without medical prediction.", icon: "Table2", input_types: ["CSV"], status: "interface_ready_descriptive_analysis", accent: "teal" },
    ]));
  }, []);
  return modules;
}

function Brand({ compact = false }: { compact?: boolean }) {
  return <Link to="/" className={`brand ${compact ? "brand-compact" : ""}`}>
    <span className="brand-mark"><HeartPulse size={22} strokeWidth={2.4} /></span>
    {!compact && <span className="brand-name">BreastCare <b>AI</b><small>RESEARCH SUITE</small></span>}
  </Link>;
}

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [health, setHealth] = useState<"checking" | "online" | "offline">("checking");
  const modules = useModules();
  const location = useLocation();

  useEffect(() => {
    getHealth().then(() => setHealth("online")).catch(() => setHealth("offline"));
  }, [location.pathname]);

  const filteredModules = modules.filter((m) => `${m.title} ${m.subtitle}`.toLowerCase().includes(query.toLowerCase()));

  return <div className="app-shell">
    {sidebarOpen && <button className="mobile-scrim" aria-label="Close navigation" onClick={() => setSidebarOpen(false)} />}
    <aside className={`sidebar ${sidebarOpen ? "sidebar-open" : ""}`}>
      <div className="sidebar-brand"><Brand /><button className="icon-button sidebar-close" onClick={() => setSidebarOpen(false)} aria-label="Close menu"><X size={18} /></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav className="nav-list">
        <NavLink to="/" end onClick={() => setSidebarOpen(false)} className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}><LayoutDashboard size={18} /> Dashboard</NavLink>
        <div className="nav-section-title">ANALYSIS MODULES</div>
        {modules.map((m) => {
          const Icon = iconMap[m.icon] ?? FlaskConical;
          return <NavLink key={m.id} to={`/modules/${m.id}`} onClick={() => setSidebarOpen(false)} className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}>
            <Icon size={18} /><span>{m.title}</span><span className="nav-dot" />
          </NavLink>;
        })}
        <div className="nav-section-title">RESEARCH</div>
        <NavLink to="/models" onClick={() => setSidebarOpen(false)} className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}><BrainCircuit size={18} /> Model registry</NavLink>
        <NavLink to="/results" onClick={() => setSidebarOpen(false)} className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}><FlaskConical size={18} /> Experiment results</NavLink>
        <NavLink to="/history" onClick={() => setSidebarOpen(false)} className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}><ClipboardList size={18} /> Analysis history</NavLink>
      </nav>
      <div className="sidebar-spacer" />
      <div className="offline-card">
        <div className="offline-card-icon"><ShieldCheck size={17} /></div>
        <div><strong>Local-first workspace</strong><p>Designed for private, local research.</p><span className={`connection-state ${health}`}><i />{health === "online" ? "API connected" : health === "offline" ? "API disconnected" : "Checking API…"}</span></div>
      </div>
      <div className="sidebar-footer"><NavLink to="/settings" className="nav-link"><Settings size={18} /> Settings</NavLink><span>Research prototype · local workflows</span></div>
    </aside>

    <main className="main-shell">
      <header className="topbar">
<div className="topbar-left">
  <button
    className="icon-button menu-toggle"
    aria-label="Open navigation"
    onClick={() => setSidebarOpen(true)}
  >
    <Menu size={21} />
  </button>

  <div className="breadcrumb">
    <span>Workspace</span>
    <span className="crumb-sep">/</span>
    <b>
      {location.pathname === "/"
        ? "Dashboard"
        : location.pathname
            .split("/")
            .filter(Boolean)
            .pop()
            ?.replace(/-/g, " ")}
    </b>
  </div>
</div>        <div className="topbar-actions">
          {searchOpen && <input autoFocus className="top-search" placeholder="Search modules…" value={query} onChange={(e) => setQuery(e.target.value)} />}
          <button className="icon-button" aria-label="Search modules" onClick={() => setSearchOpen(!searchOpen)}><Search size={19} /></button>
          <span className="topbar-divider" />
          <div className="local-pill"><span className={`status-dot ${health}`} /> Local environment</div>
          <div className="avatar"><UserRound size={18} /></div>
        </div>
      </header>
      <div className="page-wrap">
        <Routes>
          <Route path="/" element={<Dashboard modules={filteredModules} health={health} />} />
          <Route path="/modules/:moduleId" element={<ModulePage modules={modules} />} />
          <Route path="/models" element={<ModelsPage modules={modules} />} />
          <Route path="/results" element={<ExperimentResultsPage />} />
          <Route path="/history" element={<HistoryPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/login" element={<AuthPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
      <footer className="app-footer"><span>BreastCare AI <b>·</b> Research-only prototype</span><span><LockKeyhole size={13} /> Local-first by design</span></footer>
    </main>
  </div>;
}

function PageIntro({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return <div className="page-intro"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action}</div>;
}


function Dashboard({ modules, health }: { modules: ResearchModule[]; health: string }) {
  const [activeTab, setActiveTab] = useState("All modules");
  const [quickSearch, setQuickSearch] = useState("");
  const shown = modules.filter((m) => (activeTab === "All modules" || (activeTab === "Imaging" ? ["histopathology", "ct", "mri", "xray"].includes(m.id) : ["reports", "csv"].includes(m.id))) && `${m.title} ${m.subtitle}`.toLowerCase().includes(quickSearch.toLowerCase()));
  const histopathConfigured = modules.some((module) => module.id === "histopathology" && module.status === "research_model_configured");
  return <div className="page-content">
    <PageIntro eyebrow="RESEARCH WORKSPACE" title="Good to see you." description="Your multimodal breast cancer research workspace is ready to configure." action={<button className="button button-secondary" onClick={() => window.location.href = "/models"}><BrainCircuit size={16} /> Model registry <ArrowRight size={15} /></button>} />
    <section className="hero-panel">
      <div className="hero-copy"><div className="hero-kicker"><span className="hero-kicker-dot" /> MULTIMODAL RESEARCH WORKSPACE</div><h2>Bring research data<br /><em>into one workspace.</em></h2><p>Explore six workflows for descriptive data analysis, document text extraction, research image experiments, and safe imaging input review.</p><div className="hero-actions"><Link to="/modules/histopathology" className="button button-white"><Upload size={16} /> Open image analysis <ArrowRight size={15} /></Link><Link to="/modules/csv" className="hero-text-link">Explore data analysis <ArrowDownRight size={15} /></Link></div><div className="hero-proof"><span><CheckCircle2 size={14} /> Optional local CUDA research worker</span><span><CheckCircle2 size={14} /> Files are not retained by upload workflows</span></div></div>
      <div className="hero-art" aria-hidden="true"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="orbit orbit-three" /><div className="hero-core"><HeartPulse size={42} /></div><div className="floating-chip chip-one"><Microscope size={17} /><span>Pathology</span></div><div className="floating-chip chip-two"><Database size={17} /><span>Research data</span></div><div className="floating-chip chip-three"><BrainCircuit size={17} /><span>AI models</span></div><div className="hero-art-caption">One platform. Modular workflows.</div></div>
    </section>
    <div className="stat-grid">
      <StatCard icon={<FlaskConical size={19} />} label="Analysis modules" value="06" note="Separate input workflows" tone="teal" />
      <StatCard icon={<BrainCircuit size={19} />} label="Research models configured" value={histopathConfigured ? "1" : "0"} note={histopathConfigured ? "BreaKHis ResNet-18 · no clinical use" : "Optional local checkpoint"} tone="purple" />
      <StatCard icon={<Database size={19} />} label="Datasets connected" value="0" note="Configure authorized data" tone="blue" />
      <StatCard icon={<Zap size={19} />} label="Runtime mode" value={histopathConfigured ? "GPU/CPU" : "CPU"} note={histopathConfigured ? "Local research worker selects CUDA when available" : "No model worker configured"} tone="orange" />
    </div>
    <div className="section-heading"><div><div className="eyebrow">YOUR WORKSPACE</div><h2>Analysis modules</h2><p>Choose a workflow to see its supported inputs and setup status.</p></div><div className="section-tools"><div className="inline-search"><Search size={16} /><input value={quickSearch} onChange={(e) => setQuickSearch(e.target.value)} placeholder="Find a module" /></div></div></div>
    <div className="tabs" role="tablist" aria-label="Filter modules">{["All modules", "Imaging", "Documents & data"].map((tab) => <button key={tab} role="tab" aria-selected={activeTab === tab} className={`tab ${activeTab === tab ? "tab-active" : ""}`} onClick={() => setActiveTab(tab)}>{tab}</button>)}</div>
    <div className="module-grid">{shown.map((m) => <ModuleCard key={m.id} module={m} />)}</div>
    <div className="bottom-grid"><section className="surface-card readiness-card"><div className="card-title-row"><div><div className="eyebrow">ENVIRONMENT</div><h3>Local setup status</h3></div><span className={`badge ${health === "online" ? "badge-success" : "badge-neutral"}`}><span className="status-dot" />{health === "online" ? "Connected" : health === "offline" ? "API offline" : "Checking"}</span></div><div className="readiness-list"><ReadinessRow icon={<CheckCircle2 size={17} />} title="Frontend interface" detail="React application is running" done /><ReadinessRow icon={<CheckCircle2 size={17} />} title="Module navigation" detail="Six workflows registered" done /><ReadinessRow icon={<Database size={17} />} title="Database" detail="SQLite is created by the backend" done={health === "online"} /><ReadinessRow icon={<BrainCircuit size={17} />} title="Research model configuration" detail={histopathConfigured ? "Local BreaKHis checkpoint configured" : "Optional model environment not configured"} done={histopathConfigured} /></div></section><section className="surface-card research-note"><div className="note-icon"><ShieldCheck size={20} /></div><div className="eyebrow">RESPONSIBLE AI</div><h3>Research first. Clinical claims only after validation.</h3><p>The local BreaKHis model is a research baseline with weak transfer to BACH. Its output is not a diagnosis and must not guide patient care.</p><Link to="/models" className="text-link">Review model readiness <ArrowRight size={15} /></Link></section></div>
  </div>;
}


type ReadinessRowProps = {
  icon: React.ReactNode;
  title: string;
  detail: string;
  done?: boolean;
};

function ReadinessRow({
  icon,
  title,
  detail,
  done = false,
}: ReadinessRowProps) {
  return (
    <div className="readiness-row">
      <div className="readiness-icon">{icon}</div>

      <div className="readiness-content">
        <strong>{title}</strong>
        <span>{detail}</span>
      </div>

      <span className={`badge ${done ? "badge-success" : "badge-neutral"}`}>
        {done ? "Ready" : "Pending"}
      </span>
    </div>
  );
}


function StatCard({ icon, label, value, note, tone }: { icon: ReactNode; label: string; value: string; note: string; tone: string }) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-note">{note}</div></div>;
}
function ModuleCard({ module }: { module: ResearchModule }) {
  const Icon = iconMap[module.icon] ?? FlaskConical;
  const modelMissing = module.status === "interface_ready_model_missing";
  const researchModelConfigured = module.status === "research_model_configured";
  const metadataReviewReady = module.status === "metadata_review_available_model_missing";
  const featureReady = module.status === "interface_ready_text_extraction" || module.status === "interface_ready_descriptive_analysis";
  const badge = researchModelConfigured ? "Research model configured" : metadataReviewReady ? "Metadata review · no model" : module.status === "interface_ready_text_extraction" ? "Text extraction" : module.status === "interface_ready_descriptive_analysis" ? "Descriptive analysis" : modelMissing ? "Model needed" : "Pipeline planned";
  return <Link to={`/modules/${module.id}`} className="module-card"><div className="module-card-top"><div className={`module-icon ${module.accent}`}><Icon size={21} /></div><span className={`badge ${modelMissing || metadataReviewReady ? "badge-warning" : featureReady || researchModelConfigured ? "badge-success" : "badge-neutral"}`}>{badge}</span></div><h3>{module.title}</h3><div className="module-subtitle">{module.subtitle}</div><p>{module.description}</p><div className="module-card-bottom"><span className="input-hint"><FileText size={14} /> {module.input_types.slice(0, 3).join(" · ")}</span><span className="card-arrow"><ArrowRight size={17} /></span></div></Link>;
}

function ModulePage({ modules }: { modules: ResearchModule[] }) {
  const { moduleId } = useParams();
  const module = modules.find((m) => m.id === moduleId);
  const Icon = iconMap[module?.icon ?? ""] ?? FlaskConical;
  const [file, setFile] = useState<File | null>(null);
  const [notice, setNotice] = useState("");
  const [csvResult, setCsvResult] = useState<CsvAnalysisResult | null>(null);
  const [csvBusy, setCsvBusy] = useState(false);
  const [reportResult, setReportResult] = useState<ReportExtractionResult | null>(null);
  const [reportBusy, setReportBusy] = useState(false);
  const [histopathResult, setHistopathResult] = useState<HistopathologyResult | null>(null);
  const [histopathBusy, setHistopathBusy] = useState(false);
  const [includeGradCam, setIncludeGradCam] = useState(false);
  const [imagingResult, setImagingResult] = useState<ImagingInspectionResult | null>(null);
  const [imagingBusy, setImagingBusy] = useState(false);
  if (!module) return <NotFound />;
  const activeModule = module;
  function handleFile(selected: File | undefined) {
    setNotice("");
    if (!selected) return;
    setFile(selected);
    setCsvResult(null);
    setReportResult(null);
    setHistopathResult(null);
    setImagingResult(null);
    setNotice(activeModule.id === "csv" ? "CSV selected. Choose Analyze CSV to upload it for descriptive statistics." : activeModule.id === "reports" ? "Report selected. Choose Extract text to upload it for local text extraction." : activeModule.id === "histopathology" ? "Image selected. It remains local until you explicitly run the research model." : ["ct", "mri", "xray"].includes(activeModule.id) ? "Image selected. Choose Inspect input to send a single image/header for local metadata review only." : "File selected for preview only.");
  }
  async function runCsvAnalysis() {
    if (!file) { setNotice("Select a CSV file first."); return; }
    setCsvBusy(true); setNotice(""); setCsvResult(null);
    try { setCsvResult(await analyzeCsv(file)); }
    catch (error) { setNotice(error instanceof Error ? error.message : "CSV analysis failed. Check the file and backend, then try again."); }
    finally { setCsvBusy(false); }
  }
  async function runReportExtraction() {
    if (!file) { setNotice("Select a report file first."); return; }
    setReportBusy(true); setNotice(""); setReportResult(null);
    try { setReportResult(await extractReport(file)); }
    catch (error) { setNotice(error instanceof Error ? error.message : "Text extraction failed. Check the file and backend, then try again."); }
    finally { setReportBusy(false); }
  }
  async function runHistopathology() {
    if (!file) { setNotice("Select an image first."); return; }
    setHistopathBusy(true); setNotice(""); setHistopathResult(null);
    try { setHistopathResult(await predictHistopathology(file, includeGradCam)); }
    catch (error) { setNotice(error instanceof Error ? error.message : "Research model failed. Check its local configuration and try again."); }
    finally { setHistopathBusy(false); }
  }
  async function runImagingReview() {
    if (!file || !["ct", "mri", "xray"].includes(activeModule.id)) { setNotice("Select a supported imaging file first."); return; }
    setImagingBusy(true); setNotice(""); setImagingResult(null);
    try { setImagingResult(await inspectImaging(activeModule.id as "ct" | "mri" | "xray", file)); }
    catch (error) { setNotice(error instanceof Error ? error.message : "Image metadata review failed. Check the file and backend."); }
    finally { setImagingBusy(false); }
  }
  if (module.id === "csv") return <CsvWorkflow file={file} notice={notice} handleFile={handleFile} clearFile={() => { setFile(null); setCsvResult(null); setNotice(""); }} busy={csvBusy} result={csvResult} onAnalyze={runCsvAnalysis} />;
  if (module.id === "reports") return <ReportWorkflow module={module} file={file} notice={notice} handleFile={handleFile} clearFile={() => { setFile(null); setReportResult(null); setNotice(""); }} busy={reportBusy} result={reportResult} onExtract={runReportExtraction} />;
  if (module.id === "histopathology") return <HistopathologyWorkflow module={module} file={file} notice={notice} handleFile={handleFile} clearFile={() => { setFile(null); setHistopathResult(null); setNotice(""); }} busy={histopathBusy} result={histopathResult} includeGradCam={includeGradCam} setIncludeGradCam={setIncludeGradCam} onAnalyze={runHistopathology} />;
  if (["ct", "mri", "xray"].includes(module.id)) return <ImagingReviewWorkflow module={module} file={file} notice={notice} handleFile={handleFile} clearFile={() => { setFile(null); setImagingResult(null); setNotice(""); }} busy={imagingBusy} result={imagingResult} onInspect={runImagingReview} />;
  return <div className="page-content">
    <div className="back-link"><Link to="/">← Back to dashboard</Link></div>
    <PageIntro eyebrow="ANALYSIS MODULE" title={module.title} description={module.description} action={<span className="badge badge-warning">No compatible AI model</span>} />
    <div className="module-detail-grid">
      <section className="surface-card upload-panel"><div className="card-title-row"><div><div className="eyebrow">INPUT WORKSPACE</div><h3>Input review is available</h3></div><div className={`module-icon ${module.accent}`}><Icon size={21} /></div></div><p className="muted">This module does not yet have a supported processing or prediction workflow. For CT, MRI, or X-ray files, use the metadata review workflow to inspect one file.</p><div className="inline-notice"><CircleHelp size={16} />AI inference stays disabled until a compatible, licensed model and evaluation evidence are registered.</div><Link className="button button-secondary full-width" to="/models">Review model registry <ArrowRight size={15} /></Link></section>
      <aside className="module-side-column"><section className="surface-card"><div className="eyebrow">MODULE READINESS</div><h3>Input checks only</h3><p className="muted">A limited file inspection may be available. No CT-, MRI-, or radiology-specific model is installed.</p><div className="status-row"><span>AI inference</span><span className="status-value pending">Unavailable</span></div><div className="status-row"><span>Clinical validation</span><span className="status-value pending">None</span></div></section></aside>
    </div>
    <div className="medical-disclaimer"><ShieldCheck size={17} /><div><strong>Research software notice</strong><p>This software does not diagnose cancer and must not be used to make clinical decisions.</p></div></div>
  </div>;
}

function HistopathologyWorkflow({ module, file, notice, handleFile, clearFile, busy, result, includeGradCam, setIncludeGradCam, onAnalyze }: {
  module: ResearchModule; file: File | null; notice: string;
  handleFile: (file: File | undefined) => void; clearFile: () => void; busy: boolean;
  result: HistopathologyResult | null; includeGradCam: boolean; setIncludeGradCam: (value: boolean) => void;
  onAnalyze: () => void;
}) {
  const configured = module.status === "research_model_configured";
  return <div className="page-content">
    <div className="back-link"><Link to="/">← Back to dashboard</Link></div>
    <PageIntro eyebrow="RESEARCH-ONLY IMAGE WORKFLOW" title="Histopathology" description="Run the locally configured BreaKHis ResNet-18 checkpoint on a selected tissue image. This research workflow is not for diagnosis or clinical use." action={<span className={`badge ${configured ? "badge-warning" : "badge-neutral"}`}>{configured ? "Local research model configured" : "Model not configured"}</span>} />
    <section className="medical-disclaimer"><ShieldCheck size={18} /><div><strong>Research model output only — not for diagnosis or patient care</strong><p>The saved model achieved near-chance accuracy in the BACH external evaluation and did not transfer reliably to that dataset. Do not use this workflow on patient images or to guide care.</p></div></section>
    <div className="module-detail-grid">
      <section className="surface-card upload-panel"><div className="card-title-row"><div><div className="eyebrow">LOCAL IMAGE INPUT</div><h3>Choose a histopathology image</h3></div><div className={`module-icon ${module.accent}`}><Microscope size={21} /></div></div>
        <p className="muted">PNG, JPG, or TIFF up to 10 MB. The selected file stays in your browser until you choose to run the local model; the API processes it in memory and does not save it.</p>
        <label className="drop-zone"><input type="file" accept=".png,.jpg,.jpeg,.tif,.tiff,image/png,image/jpeg,image/tiff" onChange={(event) => handleFile(event.target.files?.[0])} /><span className="upload-circle"><Upload size={21} /></span><strong>{file ? file.name : "Choose a tissue image"}</strong><span>{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB · selected locally` : "PNG · JPG · TIFF · 10 MB maximum"}</span><span className="button button-secondary button-small">Browse files</span></label>
        {file && <div className="selected-file"><FileText size={18} /><div><strong>{file.name}</strong><span>{(file.size / 1024 / 1024).toFixed(2)} MB</span></div><button className="icon-button" onClick={clearFile} aria-label="Remove selected image"><X size={16} /></button></div>}
        <label className="research-toggle"><input type="checkbox" checked={includeGradCam} onChange={(event) => setIncludeGradCam(event.target.checked)} /><span>Generate Grad-CAM visualization</span></label>
        {notice && <div className="inline-notice" role="alert"><CircleHelp size={16} />{notice}</div>}
        {!configured && <div className="inline-notice"><CircleHelp size={16} /><span>Set <code>RESEARCH_MODEL_PYTHON</code> and <code>HISTOPATHOLOGY_CHECKPOINT</code> in <code>backend/.env</code>, then restart the backend. See README for the exact paths.</span></div>}
        <button className="button button-primary full-width" disabled={!configured || !file || busy} onClick={onAnalyze}><Microscope size={16} /> {busy ? "Running local research model…" : "Run research model"} <ArrowRight size={15} /></button>
        <p className="privacy-hint"><LockKeyhole size={13} /> No result is produced unless a compatible checkpoint and PyTorch environment are configured.</p>
      </section>
      <aside className="module-side-column"><section className="surface-card"><div className="eyebrow">MODEL PROVENANCE</div><h3>BreaKHis ResNet-18</h3><div className="status-row"><span>Task</span><span className="status-value pending">Benign / malignant research labels</span></div><div className="status-row"><span>Input size</span><span className="status-value success">128 × 128</span></div><div className="status-row"><span>Clinical validation</span><span className="status-value pending">None</span></div><div className="status-row"><span>External BACH accuracy</span><span className="status-value pending">49–52% mean</span></div></section><section className="surface-card"><div className="eyebrow">INTERPRETATION LIMITS</div><h3>Scores and heatmaps</h3><p className="muted">Softmax scores are not calibrated probabilities. Grad-CAM highlights image regions associated with a model output; it does not explain cause or establish tissue diagnosis.</p></section></aside>
    </div>
    {result && <section className="surface-card report-results" aria-live="polite"><div className="table-intro"><div><div className="eyebrow">RESEARCH-ONLY MODEL OUTPUT</div><h3>{result.filename}</h3><p>{result.model} · {result.training_fold} · {result.training_magnification} · {result.execution_device}</p></div><span className="badge badge-warning">Not a diagnosis</span></div><div className="research-output-grid"><div className="research-output-card"><span>Predicted class</span><strong>{result.predicted_class}</strong><small>Model output only</small></div><div className="research-output-card"><span>Benign softmax score</span><strong>{(result.class_scores.benign * 100).toFixed(1)}%</strong><small>Not calibrated</small></div><div className="research-output-card"><span>Malignant softmax score</span><strong>{(result.class_scores.malignant * 100).toFixed(1)}%</strong><small>Not calibrated</small></div></div><p className="muted">{result.score_note}</p>{result.grad_cam_overlay_png_base64 && <figure className="research-heatmap"><img src={`data:image/png;base64,${result.grad_cam_overlay_png_base64}`} alt="Grad-CAM visualization overlay for the research model output" /><figcaption>{result.explanation}</figcaption></figure>}<div className="medical-disclaimer"><ShieldCheck size={17} /><div><strong>Do not use for clinical decisions</strong><p>This model has poor transfer performance on BACH and is not clinically validated.</p></div></div></section>}
  </div>;
}

function ImagingReviewWorkflow({ module, file, notice, handleFile, clearFile, busy, result, onInspect }: {
  module: ResearchModule; file: File | null; notice: string;
  handleFile: (file: File | undefined) => void; clearFile: () => void; busy: boolean;
  result: ImagingInspectionResult | null; onInspect: () => void;
}) {
  return <div className="page-content">
    <div className="back-link"><Link to="/">← Back to dashboard</Link></div>
    <PageIntro eyebrow="INPUT REVIEW ONLY" title={module.title} description="Inspect one image or DICOM header for basic format and technical metadata. No model prediction is available for this modality." action={<span className="badge badge-warning">No AI model installed</span>} />
    <section className="medical-disclaimer"><ShieldCheck size={18} /><div><strong>Metadata inspection only — no image interpretation</strong><p>This tool does not detect or classify cancer. DICOM patient identifiers are not returned, and image files are not saved. DICOM series and NIfTI files are not supported in this phase.</p></div></section>
    <div className="module-detail-grid">
      <section className="surface-card upload-panel"><div className="card-title-row"><div><div className="eyebrow">LOCAL INPUT</div><h3>Inspect one image or DICOM instance</h3></div><div className={`module-icon ${module.accent}`}><Scan size={21} /></div></div>
        <p className="muted">DICOM (.dcm/.dicom), PNG, JPG, JPEG, or TIFF up to 10 MB. Upload starts only when you click Inspect input.</p>
        <label className="drop-zone"><input type="file" accept=".dcm,.dicom,.png,.jpg,.jpeg,.tif,.tiff,application/dicom,image/png,image/jpeg,image/tiff" onChange={(event) => handleFile(event.target.files?.[0])} /><span className="upload-circle"><Upload size={21} /></span><strong>{file ? file.name : "Choose one imaging file"}</strong><span>{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB · selected locally` : "One instance only · 10 MB maximum"}</span><span className="button button-secondary button-small">Browse files</span></label>
        {file && <div className="selected-file"><FileText size={18} /><div><strong>{file.name}</strong><span>{(file.size / 1024 / 1024).toFixed(2)} MB</span></div><button className="icon-button" onClick={clearFile} aria-label="Remove selected image"><X size={16} /></button></div>}
        {notice && <div className="inline-notice" role="alert"><CircleHelp size={16} />{notice}</div>}
        <button className="button button-primary full-width" disabled={!file || busy} onClick={onInspect}><Scan size={16} /> {busy ? "Inspecting header…" : "Inspect input"} <ArrowRight size={15} /></button>
        <p className="privacy-hint"><LockKeyhole size={13} /> Technical metadata only. No pixel-level AI inference or diagnosis.</p>
      </section>
      <aside className="module-side-column"><section className="surface-card"><div className="eyebrow">CURRENT SUPPORT</div><h3>Technical input checks</h3><div className="status-row"><span>Raster dimensions</span><span className="status-value success">Available</span></div><div className="status-row"><span>DICOM modality match</span><span className="status-value success">Available</span></div><div className="status-row"><span>DICOM series / NIfTI</span><span className="status-value pending">Not supported</span></div><div className="status-row"><span>Modality model</span><span className="status-value pending">Not installed</span></div></section><section className="surface-card"><div className="eyebrow">DATA HANDLING</div><h3>No identifying fields returned</h3><p className="muted">For DICOM, the endpoint reads the header before pixel data and returns only a small allowlist of technical fields. For raster images, it reports format and dimensions only.</p></section></aside>
    </div>
    {result && <section className="surface-card report-results" aria-live="polite"><div className="table-intro"><div><div className="eyebrow">INPUT METADATA</div><h3>{file?.name ?? "Input metadata"}</h3><p>{result.inspection_type === "dicom_header_metadata" ? "DICOM header, pixel data not read" : "Raster image metadata"}</p></div><span className="badge badge-warning">No AI inference</span></div><div className="results-detail-list imaging-metadata-list"><div><span>Module selected</span><strong>{module.title}</strong></div><div><span>Modality</span><strong>{result.modality_check === "matches_selected_module" ? result.metadata.modality : "Not verifiable from a raster file"}</strong></div>{result.metadata.format && <div><span>File format</span><strong>{result.metadata.format} · {result.metadata.mode}</strong></div>}<div><span>Image dimensions</span><strong>{result.metadata.rows ? `${result.metadata.rows} × ${result.metadata.columns} pixels` : `${result.metadata.width} × ${result.metadata.height} pixels`}</strong></div>{result.metadata.frames && <div><span>Frames</span><strong>{result.metadata.frames}</strong></div>}{result.metadata.pixel_spacing_mm && <div><span>Pixel spacing</span><strong>{result.metadata.pixel_spacing_mm.join(" × ")} mm</strong></div>}{result.metadata.slice_thickness_mm && <div><span>Slice thickness</span><strong>{result.metadata.slice_thickness_mm.join(" × ")} mm</strong></div>}</div>{result.note && <p className="muted imaging-result-note">{result.note}</p>}</section>}
  </div>;
}

function CsvWorkflow({ file, notice, handleFile, clearFile, busy, result, onAnalyze }: {
  file: File | null; notice: string;
  handleFile: (file: File | undefined) => void; clearFile: () => void; busy: boolean;
  result: CsvAnalysisResult | null; onAnalyze: () => void;
}) {
  return <div className="page-content">
    <div className="back-link"><Link to="/">← Back to dashboard</Link></div>
    <PageIntro eyebrow="ANALYSIS MODULE" title="CSV Analysis" description="Upload a CSV to inspect its structure, missing values, descriptive statistics and chart-ready summaries." action={<span className="badge badge-success">Descriptive analysis available</span>} />
    <div className="module-detail-grid">
      <section className="surface-card upload-panel"><div className="card-title-row"><div><div className="eyebrow">INPUT WORKSPACE</div><h3>Analyze a dataset</h3></div><div className="module-icon teal"><Table2 size={21} /></div></div>
        <p className="muted">CSV files up to 10 MB are processed in memory and are not saved by this endpoint.</p>
        <label className="drop-zone"><input type="file" accept=".csv,text/csv" onChange={(e) => handleFile(e.target.files?.[0])} /><span className="upload-circle"><Upload size={21} /></span><strong>{file ? file.name : "Choose a CSV file"}</strong><span>{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB · ready to upload` : "UTF-8 and common text encodings supported · 10 MB maximum"}</span><span className="button button-secondary button-small">Browse files</span></label>
        {file && <div className="selected-file"><FileText size={18} /><div><strong>{file.name}</strong><span>{(file.size / 1024 / 1024).toFixed(2)} MB</span></div><button className="icon-button" onClick={clearFile} aria-label="Remove selected file"><X size={16} /></button></div>}
        {notice && <div className="inline-notice" role="alert"><CircleHelp size={16} />{notice}</div>}
        <button className="button button-primary full-width" disabled={busy || !file} onClick={onAnalyze}><Table2 size={16} /> {busy ? "Analyzing CSV…" : "Analyze CSV"} <ArrowRight size={15} /></button>
        <p className="privacy-hint"><LockKeyhole size={13} /> Descriptive summaries only. No diagnosis, risk score or medical prediction is produced.</p>
      </section>
      <aside className="module-side-column"><section className="surface-card"><div className="eyebrow">ANALYSIS SCOPE</div><h3>Dataset exploration</h3><p className="muted">Reports dimensions, inferred column types, missingness, numeric summaries and frequent categories for charts.</p><div className="status-row"><span>Upload limit</span><span className="status-value success">10 MB</span></div><div className="status-row"><span>Medical prediction</span><span className="status-value pending">Not performed</span></div><div className="status-row"><span>File persistence</span><span className="status-value success">None</span></div></section><section className="medical-disclaimer"><ShieldCheck size={17} /><div><strong>Descriptive statistics are not diagnosis</strong><p>These summaries describe the uploaded data and must not be used to make clinical decisions.</p></div></section></aside>
    </div>
    {result && <section className="csv-results surface-card" aria-live="polite">
      <div className="table-intro"><div><div className="eyebrow">DESCRIPTIVE RESULTS</div><h3>{result.filename}</h3><p>{result.shape.rows.toLocaleString()} rows · {result.shape.columns} columns · summary only</p></div><span className="badge badge-success">No diagnosis</span></div>
      <h4>Columns and missing values</h4><div className="table-scroll"><table><thead><tr><th>Column</th><th>Type</th><th>Missing</th><th>Missing %</th></tr></thead><tbody>{result.columns.map((col) => <tr key={col.name}><td><strong>{col.name}</strong></td><td>{col.dtype}</td><td>{col.missing.toLocaleString()}</td><td>{col.missing_percent}%</td></tr>)}</tbody></table></div>
      <h4>Numeric descriptive statistics</h4>{result.chart_data.numeric.length ? <div className="table-scroll"><table><thead><tr><th>Column</th><th>Count</th><th>Mean</th><th>Std</th><th>Min</th><th>Median</th><th>Max</th></tr></thead><tbody>{result.chart_data.numeric.map((item) => <tr key={item.column}><td><strong>{item.column}</strong></td><td>{item.count}</td><td>{formatStat(item.mean)}</td><td>{formatStat(item.std)}</td><td>{formatStat(item.min)}</td><td>{formatStat(item.median)}</td><td>{formatStat(item.max)}</td></tr>)}</tbody></table></div> : <p className="muted csv-empty">No numeric columns were detected.</p>}
      {result.chart_data.categorical.length > 0 && <><h4>Chart-ready category counts <small>(top 20 per column)</small></h4><div className="csv-category-grid">{result.chart_data.categorical.map((group) => <div className="csv-category-card" key={group.column}><strong>{group.column}</strong>{group.counts.map((entry) => <div key={entry.label}><span>{entry.label}</span><b>{entry.count}</b></div>)}</div>)}</div></>}
    </section>}
  </div>;
}
function formatStat(value: number | null) { return value === null ? "—" : Number(value.toPrecision(5)).toLocaleString(); }

function ReportWorkflow({ module, file, notice, handleFile, clearFile, busy, result, onExtract }: {
  module: ResearchModule; file: File | null; notice: string; handleFile: (file: File | undefined) => void;
  clearFile: () => void; busy: boolean; result: ReportExtractionResult | null; onExtract: () => void;
}) {
  return <div className="page-content">
    <div className="back-link"><Link to="/">← Back to dashboard</Link></div>
    <PageIntro eyebrow="DOCUMENT WORKFLOW" title={module.title} description="Extract text from a report PDF or image, then review the extracted text yourself." action={<span className="badge badge-success">Text extraction available</span>} />
    <div className="module-detail-grid">
      <section className="surface-card upload-panel"><div className="card-title-row"><div><div className="eyebrow">INPUT WORKSPACE</div><h3>Extract report text</h3></div><div className="module-icon green"><FileText size={21} /></div></div>
        <p className="muted">PDF and image files up to 10 MB. Processing is local; uploaded files are not saved by this endpoint.</p>
        <label className="drop-zone"><input type="file" accept=".pdf,.png,.jpg,.jpeg,.tif,.tiff,.bmp,application/pdf,image/*" onChange={(e) => handleFile(e.target.files?.[0])} /><span className="upload-circle"><Upload size={21} /></span><strong>{file ? file.name : "Choose a report PDF or image"}</strong><span>{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB · ready to upload` : "PDF (up to 20 pages), PNG, JPG, TIFF or BMP · 10 MB maximum"}</span><span className="button button-secondary button-small">Browse files</span></label>
        {file && <div className="selected-file"><FileText size={18} /><div><strong>{file.name}</strong><span>{(file.size / 1024 / 1024).toFixed(2)} MB</span></div><button className="icon-button" onClick={clearFile} aria-label="Remove selected file"><X size={16} /></button></div>}
        {notice && <div className="inline-notice" role="alert"><CircleHelp size={16} />{notice}</div>}
        <button className="button button-primary full-width" disabled={busy || !file} onClick={onExtract}><FileText size={16} /> {busy ? "Extracting text…" : "Extract text"} <ArrowRight size={15} /></button>
        <p className="privacy-hint"><LockKeyhole size={13} /> Text extraction only. No diagnosis, summary, or clinical interpretation is produced.</p>
      </section>
      <aside className="module-side-column"><section className="surface-card"><div className="eyebrow">WHAT THIS DOES</div><h3>Text for your review</h3><p className="muted">Digital PDFs use their embedded text. Scanned PDFs and images use the local Tesseract OCR engine.</p><div className="status-row"><span>Maximum file size</span><span className="status-value success">10 MB</span></div><div className="status-row"><span>Scanned PDF length</span><span className="status-value success">20 pages</span></div><div className="status-row"><span>Medical interpretation</span><span className="status-value pending">Not performed</span></div></section><section className="medical-disclaimer"><ShieldCheck size={17} /><div><strong>Review OCR output carefully</strong><p>OCR can miss or misread text. Confirm extracted content against the original document; do not use it alone for clinical decisions.</p></div></section></aside>
    </div>
    {result && <section className="report-results surface-card" aria-live="polite"><div className="table-intro"><div><div className="eyebrow">EXTRACTED TEXT</div><h3>{result.filename}</h3><p>{result.pages} {result.pages === 1 ? "page" : "pages"} · {result.character_count.toLocaleString()} characters · {result.method === "ocr" ? "OCR" : "embedded PDF text"}</p></div><span className="badge badge-neutral">Review required</span></div><pre className="extracted-report-text">{result.text || "No text was detected in this file."}</pre><div className="table-footnote"><ShieldCheck size={15} /> Text extraction only; the application does not interpret medical meaning or provide diagnosis.</div></section>}
  </div>;
}

function ModelsPage({ modules }: { modules: ResearchModule[] }) {
  const histopathConfigured = modules.some((module) => module.id === "histopathology" && module.status === "research_model_configured");
  const rows = [
    ["BreaKHis ResNet-18 research baseline", "PNG / JPG / TIFF histopathology", histopathConfigured ? "Configured · runtime check on use" : "Not configured"],
    ["BRCA1 / BRCA2 predictor", "Matched pathology + mutation labels", "Not installed"],
    ["CT-specific model", "Compatible CT series", "Not installed"],
    ["MRI-specific model", "Supported MRI sequences", "Not installed"],
    ["Radiology / mammography model", "Validated intended modality", "Not installed"],
    ["Document text extraction", "PDF / image reports", "Available (Tesseract required for OCR)"],
    ["CSV descriptive analysis", "Tabular datasets", "Available"],
  ];
  return <div className="page-content"><PageIntro eyebrow="RESEARCH TOOLS" title="Model registry" description="Track model readiness and requirements before enabling research workflows." /><section className="surface-card table-card"><div className="table-intro"><div><h3>Registered model slots</h3><p>Checkpoint weights stay outside the source archive. A configured path does not imply clinical validity or verified runtime compatibility.</p></div><span className={`badge ${histopathConfigured ? "badge-warning" : "badge-neutral"}`}>{histopathConfigured ? "1 research model configured" : "0 research models configured"}</span></div><div className="table-scroll"><table><thead><tr><th>Model / processor</th><th>Expected input</th><th>Status</th></tr></thead><tbody>{rows.map((r) => <tr key={r[0]}><td><strong>{r[0]}</strong></td><td>{r[1]}</td><td><span className="status-value pending">{r[2]}</span></td></tr>)}</tbody></table></div><div className="table-footnote"><CircleHelp size={15} /> CT, MRI and radiology checkpoints are not included; their workflows remain unavailable until compatible, licensed models and evidence are added.</div></section><section className="info-banner"><CloudDownload size={20} /><div><strong>Local model configuration</strong><p>Set the existing CUDA-enabled Python path and checkpoint in <code>backend/.env</code>. This project does not install or pin PyTorch.</p></div></section></div>;
}

function ExperimentResultsPage() {
  const results = [
    { magnification: "40×", accuracy: "77.0%", accuracyRange: "72.1–80.7%", recall: "82.9%", recallRange: "76.7–89.5%", specificity: "65.4%", specificityRange: "43.3–76.6%", balanced: "74.1%" },
    { magnification: "100×", accuracy: "77.2%", accuracyRange: "73.6–80.8%", recall: "83.7%", recallRange: "72.5–92.1%", specificity: "64.4%", specificityRange: "46.9–75.5%", balanced: "74.1%" },
    { magnification: "200×", accuracy: "81.4%", accuracyRange: "75.8–84.5%", recall: "82.9%", recallRange: "70.2–88.8%", specificity: "78.1%", specificityRange: "64.9–86.1%", balanced: "80.5%" },
    { magnification: "400×", accuracy: "81.3%", accuracyRange: "76.9–84.7%", recall: "83.0%", recallRange: "79.2–86.8%", specificity: "78.2%", specificityRange: "71.6–86.6%", balanced: "80.6%" },
  ];

  return <div className="page-content experiment-results-page">
    <PageIntro eyebrow="RESEARCH EVALUATION" title="BreaKHis experiment results" description="Five-fold summary of the research-only ResNet-18 runs across four image magnifications." />
    <section className="medical-disclaimer" aria-label="Research-only notice">
      <ShieldCheck size={18} />
      <div><strong>Research results only — not for diagnosis or clinical decisions</strong><p>This model has not been clinically validated and must not be used to assess patient images.</p></div>
    </section>

    <div className="stat-grid experiment-stat-grid">
      <StatCard icon={<FlaskConical size={19} />} label="Magnifications evaluated" value="4" note="40× · 100× · 200× · 400×" tone="teal" />
      <StatCard icon={<Activity size={19} />} label="Fold-level runs" value="20" note="Five official splits per magnification" tone="blue" />
      <StatCard icon={<BrainCircuit size={19} />} label="Model" value="ResNet-18" note="ImageNet weights; research baseline" tone="purple" />
      <StatCard icon={<ShieldCheck size={19} />} label="BACH research evaluation" value="400 images" note="49–52% mean accuracy; weak transfer" tone="orange" />
    </div>

    <section className="surface-card table-card experiment-table-card">
      <div className="table-intro"><div><div className="eyebrow">MEAN FOLD METRICS</div><h3>Magnification comparison</h3><p>Arithmetic mean across five fold-level runs; ranges show minimum to maximum fold results.</p></div><span className="badge badge-neutral">20 runs</span></div>
      <div className="table-scroll"><table className="experiment-table"><thead><tr><th>Magnification</th><th>Accuracy</th><th>Malignant recall</th><th>Benign specificity</th><th>Balanced accuracy</th></tr></thead><tbody>{results.map((row) => <tr key={row.magnification}><td><strong>{row.magnification}</strong></td><td><strong>{row.accuracy}</strong><small>{row.accuracyRange}</small></td><td><strong>{row.recall}</strong><small>{row.recallRange}</small></td><td><strong>{row.specificity}</strong><small>{row.specificityRange}</small></td><td><strong>{row.balanced}</strong></td></tr>)}</tbody></table></div>
      <div className="table-footnote"><CircleHelp size={15} /> Fold test sets overlap. Use mean fold-level metrics; do not interpret their counts as unique cases pooled into one test set.</div>
    </section>

    <section className="surface-card table-card experiment-table-card bach-results-card">
      <div className="table-intro"><div><div className="eyebrow">SEPARATE EXTERNAL RESEARCH EVALUATION</div><h3>BACH transfer results</h3><p>Each saved BreaKHis fold model was evaluated on the same 400 BACH Photos images; means below summarize five models per training magnification.</p></div><span className="badge badge-warning">Not clinical validation</span></div>
      <div className="table-scroll"><table className="experiment-table"><thead><tr><th>BreaKHis training magnification</th><th>BACH accuracy</th><th>Carcinoma recall</th><th>Non-carcinoma specificity</th><th>Balanced accuracy</th></tr></thead><tbody>
        <tr><td><strong>40×</strong></td><td>50.2%</td><td>70.1%</td><td>30.3%</td><td>50.2%</td></tr>
        <tr><td><strong>100×</strong></td><td>49.2%</td><td>79.6%</td><td>18.7%</td><td>49.2%</td></tr>
        <tr><td><strong>200×</strong></td><td>52.1%</td><td>79.7%</td><td>24.5%</td><td>52.1%</td></tr>
        <tr><td><strong>400×</strong></td><td>49.2%</td><td>85.7%</td><td>12.6%</td><td>49.2%</td></tr>
      </tbody></table></div>
      <div className="table-footnote"><CircleHelp size={15} /> Study-specific binary mapping: Benign + Normal → non-carcinoma; InSitu + Invasive → carcinoma. Low specificity shows many non-carcinoma images were labeled carcinoma. Results are near chance and indicate poor transfer in this setup.</div>
    </section>

    <div className="results-detail-grid">
      <section className="surface-card"><div className="eyebrow">EXPERIMENT SETUP</div><h3>How these results were produced</h3><div className="results-detail-list"><div><span>Dataset</span><strong>BreaKHis</strong></div><div><span>Task</span><strong>Benign vs malignant image classification</strong></div><div><span>Input size</span><strong>128 × 128 pixels</strong></div><div><span>Training</span><strong>Layer 4 and classifier fine-tuned; early stopping on validation loss</strong></div><div><span>Group separation</span><strong>Fit, validation, and test groups did not overlap within each run</strong></div></div></section>
      <section className="surface-card results-reading-card"><div className="eyebrow">INTERPRETATION</div><h3>External transfer was poor</h3><p>On BreaKHis, the 200× and 400× runs had higher mean accuracy than the 40× and 100× runs, with no reliable winning magnification established.</p><p>On BACH, all magnification groups were near 50% accuracy and had low non-carcinoma specificity. These models should not be used on patient images or for clinical decisions.</p><Link to="/models" className="text-link">Review model readiness <ArrowRight size={15} /></Link></section>
    </div>
  </div>;
}

function HistoryPage() { return <div className="page-content"><PageIntro eyebrow="RESEARCH RECORDS" title="Analysis history" description="Results are shown in the current browser session; persistent history is not enabled." /><div className="empty-state surface-card"><div className="empty-state-icon"><ClipboardList size={27} /></div><h3>No saved analyses</h3><p>CSV summaries, extracted report text, imaging metadata, and optional research model outputs are returned for the current session only. The application does not retain uploaded files or create a persistent analysis history.</p><Link to="/" className="button button-primary">Explore modules <ArrowRight size={15} /></Link></div></div>; }
function SettingsPage() { return <div className="page-content"><PageIntro eyebrow="PREFERENCES" title="Settings" description="Local environment and project configuration." /><div className="settings-grid"><section className="surface-card"><div className="card-title-row"><h3>Runtime</h3><Zap size={19} /></div><div className="settings-row"><div><strong>Execution mode</strong><p>CSV, OCR, and metadata review run locally. The optional histopathology worker uses CUDA when available in its configured Python environment, otherwise CPU.</p></div><span className="badge badge-neutral">Local</span></div><div className="settings-row"><div><strong>Model availability</strong><p>Only the BreaKHis research checkpoint can be configured. CT, MRI, and radiology prediction models are not included.</p></div><span className="badge badge-warning">Research only</span></div><div className="settings-row"><div><strong>Connectivity</strong><p>After dependencies are installed, the interface and API can run locally.</p></div><span className="badge badge-success">Local</span></div></section><section className="surface-card"><div className="card-title-row"><h3>Account</h3><UserRound size={19} /></div><p className="muted">Registration and login API endpoints and a basic frontend form are available. Authenticated access is not required for the local research workflows.</p><Link className="text-link" to="/login">Open account page <ArrowRight size={15} /></Link></section></div></div>; }
function AuthPage() {
  const [mode, setMode] = useState<"login" | "register">("register");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      if (mode === "register") {
        const response = await fetch(`${API_BASE}/api/auth/register`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, username, password }) });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail ?? "Registration failed");
        setMessage("Account created. You can now sign in.");
        setMode("login");
      } else {
        const response = await fetch(`${API_BASE}/api/auth/login`, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ username: username || email, password }) });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail ?? "Login failed");
        localStorage.setItem("breastcare_access_token", data.access_token);
        setMessage("Signed in. This foundation stores the token locally; protected dashboard flows will be completed in a later phase.");
        setTimeout(() => navigate("/"), 700);
      }
    } catch (err) { setMessage(err instanceof Error ? err.message : "Request failed"); }
    finally { setBusy(false); }
  }
  return <div className="auth-wrap"><section className="auth-card surface-card"><div className="auth-brand"><Brand /></div><div className="eyebrow">LOCAL RESEARCH ACCOUNT</div><h1>{mode === "register" ? "Create your account" : "Welcome back"}</h1><p className="muted">Account access for your local BreastCare AI workspace.</p><div className="auth-tabs"><button className={mode === "register" ? "selected" : ""} onClick={() => { setMode("register"); setMessage(""); }}>Register</button><button className={mode === "login" ? "selected" : ""} onClick={() => { setMode("login"); setMessage(""); }}>Sign in</button></div><form onSubmit={submit} className="auth-form">{mode === "register" && <div className="form-field"><label>Email</label><input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" /></div>}{mode === "login" && <div className="form-field"><label>Email or username</label><input required value={username || email} onChange={(e) => { setUsername(e.target.value); setEmail(e.target.value); }} placeholder="Enter email or username" /></div>}{mode === "register" && <div className="form-field"><label>Username</label><input required minLength={3} value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Choose a username" /></div>}<div className="form-field"><label>Password</label><input type="password" required minLength={mode === "register" ? 10 : 1} value={password} onChange={(e) => setPassword(e.target.value)} placeholder={mode === "register" ? "At least 10 characters" : "Your password"} /></div><button className="button button-primary full-width" disabled={busy}>{busy ? "Please wait…" : mode === "register" ? "Create account" : "Sign in"} <ArrowRight size={15} /></button>{message && <div className="inline-notice">{message}</div>}</form><p className="privacy-hint"><LockKeyhole size={13} /> Use only a local development environment. Configure a strong secret before any shared deployment.</p></section></div>;
}
function NotFound() { return <div className="empty-state surface-card"><h2>Page not found</h2><p>The page you requested does not exist.</p><Link className="button button-primary" to="/">Return to dashboard</Link></div>; }

export default App;
