@echo off
setlocal
cd /d "%~dp0"
echo ===========================================
echo   BreastCare AI - Phase 2.2 local launcher
echo ===========================================
where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Install Python 3.11 or 3.12 and try again.
  pause
  exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js was not found. Install Node.js 20 LTS or newer and try again.
  pause
  exit /b 1
)
if not exist backend\.venv\Scripts\python.exe (
  echo Creating backend virtual environment...
  python -m venv backend\.venv
  if errorlevel 1 goto fail
)
echo Installing/verifying backend dependencies...
backend\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
if errorlevel 1 goto fail
if not exist frontend\node_modules (
  echo Installing frontend dependencies...
  pushd frontend
  call npm install
  if errorlevel 1 (popd & goto fail)
  popd
)
echo Starting API and frontend in separate windows...
start "BreastCare AI API" cmd /k "cd /d ""%~dp0backend"" && ..\backend\.venv\Scripts\python.exe -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000"
start "BreastCare AI Frontend" cmd /k "cd /d ""%~dp0frontend"" && npm run dev -- --host 127.0.0.1"
echo Frontend: http://localhost:5173
echo API docs: http://127.0.0.1:8000/docs
echo Close the two opened terminal windows to stop the services.
exit /b 0
:fail
echo Setup failed. Review the error above and see README.md troubleshooting.
pause
exit /b 1
