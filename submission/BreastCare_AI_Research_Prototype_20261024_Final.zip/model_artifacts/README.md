# Model artifacts

No pretrained medical model weights are bundled in Phase 1.

Add weights only after verifying:
- the model's intended modality and task
- compatible preprocessing and input dimensions
- dataset provenance and licensing
- checkpoint integrity
- independent evaluation and known limitations

Never label a model "available" merely because its architecture code exists. Do not commit large or restricted weights to Git; use a documented authorized download or a separate release asset.
