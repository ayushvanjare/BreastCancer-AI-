# BreastCare AI — Research Prototype

A local-first research prototype combining tabular exploration, report text extraction, imaging input review, and an optional BreaKHis histopathology research experiment.

## Included in this Phase 2.2 release
- React + TypeScript + Vite responsive dashboard (white, navy, teal)
- Six dedicated module entry pages: histopathology, CT, MRI, X-ray/mammography, doctor reports, CSV
- Python FastAPI backend with health, module metadata, registration, login, and demo analysis endpoints
- SQLite by default for easy local setup; database file is created on first startup
- Password hashing using Python's standard-library PBKDF2-HMAC and signed bearer tokens
- Docker Compose option
- Windows, PowerShell, and Linux/macOS launch scripts
- Basic automated backend tests and a model manifest
- CSV upload (10 MB maximum) with shape, column types, missingness, numeric descriptive statistics and chart-ready category counts
- Doctor report text extraction from digital/scanned PDFs and images (10 MB maximum; OCR for scans)
- Five-fold BreaKHis experiment results plus BACH external research evaluation
- Optional local ResNet-18 histopathology inference and Grad-CAM visualization, only when a compatible local checkpoint and PyTorch environment are configured
- Single-file CT/MRI/X-ray metadata review for raster images or DICOM headers; this is not image inference
- No internet connection required after dependencies have been installed

## Important medical AI limitations
This is a research software prototype, not a clinically validated diagnostic product. Model weights and datasets are not bundled. The optional BreaKHis ResNet-18 workflow had near-chance accuracy and poor specificity on the separate BACH evaluation; its output is not a diagnosis. CT, MRI, and radiology workflows inspect basic file metadata only and have no prediction models. CSV analysis returns descriptive statistics only. Doctor report processing extracts text only; OCR may misread content and does not summarize or interpret it. Do not use this software for clinical decisions.

## Requirements
- Python 3.11 or 3.12 recommended
- Node.js 20 LTS or newer (npm included)
- Optional: Docker Desktop / Docker Engine with Compose
- Optional: Git
- Tesseract OCR installed and available on `PATH` for scanned PDFs and image reports (digital PDFs can be read without Tesseract)

The dashboard, CSV, reports, and metadata review do not require a GPU. Optional histopathology inference uses a separate configured Python environment with PyTorch and torchvision; the project never installs or pins PyTorch.

## Run on Windows (recommended)
1. Extract the ZIP to a normal writable folder.
2. Open PowerShell in the extracted `BreastCare_AI_Phase2_2` folder.
3. Run the included launch script:
   ```powershell
   .\run_windows.ps1
   ```
   If PowerShell policy blocks scripts, use Command Prompt:
   ```bat
   run_windows.bat
   ```
4. Open the frontend at `http://localhost:5173`.
5. Backend API docs: `http://127.0.0.1:8000/docs`.

The first setup requires internet access to install Python and npm dependencies. After installation, the dashboard and API run locally. The scripts do not install or pin PyTorch and do not download model weights. To preserve an existing CUDA-enabled PyTorch installation, use its existing environment and install only the backend requirements if necessary; these requirements do not list PyTorch.

## Run manually
### Backend
```bash
cd backend
python -m venv .venv
# Windows PowerShell: .\.venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

### Frontend
In a second terminal:
```bash
cd frontend
npm install
npm run dev
```

## Environment configuration
Copy `backend/.env.example` to `backend/.env` if you want to customize settings. A random development secret is generated when `APP_SECRET_KEY` is not supplied; set a stable, strong secret for any shared deployment. Never expose this development server directly to the public internet.

## API endpoints
- `GET /api/health` — status and configured database
- `GET /api/modules` — six module descriptions and readiness
- `POST /api/auth/register` — `{ "email": "...", "username": "...", "password": "..." }`
- `POST /api/auth/login` — form-encoded `username` (email or username) and `password`
- `GET /api/auth/me` — current user (Bearer token)
- `POST /api/analysis` — authenticated readiness endpoint; it does not fabricate predictions
- `POST /api/csv/analyze` — multipart field `file`; accepts CSV files up to 10 MB and returns descriptive summaries only. Files are analyzed in memory and not persisted.
- `POST /api/reports/extract` — multipart field `file`; accepts PDF/image reports up to 10 MB and returns extracted text only. Files are processed in memory and not persisted. Scanned PDFs are limited to 20 pages.
- `POST /api/imaging/inspect` — multipart fields `module_id` and `file`; inspects one raster image or DICOM header up to 10 MB. No pixel prediction or patient identifiers are returned.
- `POST /api/research/histopathology/predict` — multipart fields `file` and optional `explain`; optional local BreaKHis ResNet-18 scores and Grad-CAM, explicitly research-only. Requires the separate model configuration below.
- `GET /docs` — interactive API documentation

## Git repository
This folder includes `.gitignore` and an initial Git setup helper. To create a repository:
```bash
git init
git add .
git commit -m "Initial BreastCare AI Phase 1 foundation"
```
Then create an empty repository on your Git host and follow its instructions to add a remote and push. A remote GitHub/GitLab repository is not created automatically by this package.

For offline sharing, a companion `BreastCare_AI_Phase1.bundle` can be imported with:
```bash
git clone BreastCare_AI_Phase1.bundle BreastCare_AI
```
A Git bundle carries Git history and source code, but not ignored model weights, private datasets, or local environment files.

## Tests
```bash
cd backend
python -m pip install -r requirements-dev.txt
pytest -q
```

## Phase 2.1 CSV workflow
Select **CSV Analysis** in the dashboard, choose a `.csv` file, and click **Analyze CSV**. The endpoint checks the extension and compatible content type, reads at most 10 MB plus one byte, tries common text encodings, parses with pandas, and returns dimensions, inferred dtypes, missing-value counts/percentages, numeric summary statistics, and top category counts suitable for charts. Empty, malformed, unsupported, and oversized inputs return actionable HTTP errors. No uploaded file is written to disk.

### Run manually on Windows PowerShell
Backend terminal (from the project root):
```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
Frontend terminal (from the project root):
```powershell
cd frontend
npm install
npm run dev
```
Open `http://localhost:5173`. If `.venv` already contains CUDA-enabled PyTorch, activate that environment and install the listed backend requirements there; PyTorch is neither installed nor changed by this project.

## Phase 2.2 doctor report text extraction
Open **Doctor Reports**, select a PDF or image, and click **Extract text**. Digital PDFs are read from their embedded text. Scanned PDFs and images are processed with Tesseract OCR installed locally on the computer. Input files are not saved by the endpoint. Uploads are limited to 10 MB; PDFs are limited to 20 pages. The interface returns extracted text for human review and does not summarize, interpret, or diagnose. OCR can omit or misread content, so compare the output with the source report. If OCR reports that Tesseract is unavailable, install Tesseract OCR, make sure its executable is on `PATH`, and restart the backend terminal.

## Research-only experiment results and optional inference
Open **Experiment results** to view the five-fold BreaKHis summary and the separate 400-image BACH external evaluation. The BACH models were near chance with low non-carcinoma specificity. The output is not clinical validation or patient-care evidence. Detailed methods and limitations are in `BREAKHIS_EXPERIMENT_SUMMARY.md` and `PROJECT_SUBMISSION_REPORT.md`.

Optional local inference is available only with a compatible checkpoint from `train_breakhis_resnet18.py` and a Python interpreter that already has PyTorch, torchvision, CUDA (optional), and Pillow installed. Set these in `backend/.env` (example Windows paths):
```dotenv
RESEARCH_MODEL_PYTHON=C:/Users/your-name/Downloads/BreastCare_AI_Phase1/BreastCare_AI/.venv/Scripts/python.exe
HISTOPATHOLOGY_CHECKPOINT=C:/Users/your-name/Downloads/BreaKHis/resnet18_results/fold2_400x/resnet18_fold2_400x.pt
```
Restart the backend after changing `.env`. This example selects a pre-existing BreaKHis research checkpoint; its BACH results were poor. Do not infer from patient images. Grad-CAM is a visualization of model activations, not an explanation of medical causation.

The CT, MRI, and X-ray pages only inspect single-file metadata. They do not support DICOM series, NIfTI, segmentation, or prediction. Compatible modality-specific datasets, licensing, models, and evaluation evidence are not provided, so real modality-specific prediction cannot be responsibly enabled from the files available here.

### Optional BACH external research evaluation
After obtaining permission for the intended BACH use, `evaluate_bach_external.py` evaluates the saved BreaKHis ResNet-18 checkpoints on the four-class BACH `Photos` folder. It decodes and resizes images in memory and does not overwrite the dataset. The research-only binary mapping is `Benign` and `Normal` → non-carcinoma, and `InSitu` and `Invasive` → carcinoma; the original BACH labels remain in the per-image predictions. This mapping is study-specific, and results must be reported separately from BreaKHis results. The script evaluates all 20 saved fold/magnification checkpoints and writes JSON metrics, a summary CSV, and per-image predictions. Fold-model spread is not a patient-level confidence interval.

Run from the project root in Windows PowerShell, using the existing CUDA-enabled PyTorch environment (the command does not install or pin PyTorch):
```powershell
$python = "$env:USERPROFILE\Downloads\BreastCare_AI_Phase1\BreastCare_AI\.venv\Scripts\python.exe"
& $python .\evaluate_bach_external.py `
  --photos-dir "$env:USERPROFILE\Downloads\BACH_External\extracted\ICIAR2018_BACH_Challenge\Photos" `
  --checkpoints-dir "$env:USERPROFILE\Downloads\BreaKHis\resnet18_results" `
  --output-dir .\research_results\bach_external `
  --device cuda
```
The outputs are research-only, not for diagnosis or clinical use, and not clinical validation. Keep the dataset permission and required attribution with any report.

## Completed project milestones and remaining research inputs
- See `PROJECT_MILESTONES.md` for a delivery checklist and the exact boundary between implemented workflows and model-dependent milestones.
- Local dashboard and FastAPI API with six workflows.
- CSV data-quality summaries, descriptive statistics, and chart-ready data; report text extraction; single-image/DICOM-header metadata review.
- BreaKHis baseline training, fold-wise metrics, BACH external evaluation, result reporting, optional local research inference, and Grad-CAM visualization.
- Real CT/MRI/X-ray prediction, BRCA mutation prediction, clinical validation, and persistent analysis history are not included. These require compatible, licensed data and appropriately validated models; a UI page alone would not constitute those milestones.
