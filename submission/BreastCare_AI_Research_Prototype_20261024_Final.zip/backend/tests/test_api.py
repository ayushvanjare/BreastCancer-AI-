import os
import tempfile
from fastapi.testclient import TestClient

# Use an isolated DB before importing the app.
tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
tmp.close()
os.environ["DATABASE_URL"] = f"sqlite:///{tmp.name}"
os.environ["APP_SECRET_KEY"] = "test-secret-key-that-is-long-enough-for-tests"
os.environ["FRONTEND_ORIGIN"] = "http://localhost:5173"

from app.config import settings  # noqa: E402
from app.main import app  # noqa: E402

client = TestClient(app)

def test_health_and_modules():
    assert client.get("/api/health").status_code == 200
    data = client.get("/api/modules").json()["modules"]
    assert len(data) == 6
    assert {m["id"] for m in data} == {"histopathology", "ct", "mri", "xray", "reports", "csv"}

def test_register_login_and_me():
    import uuid
    suffix = uuid.uuid4().hex[:10]
    r = client.post("/api/auth/register", json={
        "email": f"{suffix}@example.com",
        "username": f"user_{suffix}",
        "password": "a-long-test-password-123",
    })
    assert r.status_code == 201, r.text
    login = client.post("/api/auth/login", data={
        "username": f"user_{suffix}",
        "password": "a-long-test-password-123",
    })
    assert login.status_code == 200, login.text
    token = login.json()["access_token"]
    me = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me.status_code == 200
    assert me.json()["username"] == f"user_{suffix}"

def test_analysis_does_not_fake_prediction():
    reg = client.post("/api/auth/register", json={
        "email": "analysis-test@example.com",
        "username": "analysis_test",
        "password": "a-long-test-password-123",
    })
    # If a prior test run left this user, log in instead.
    if reg.status_code == 409:
        login = client.post("/api/auth/login", data={
            "username": "analysis_test",
            "password": "a-long-test-password-123",
        })
        token = login.json()["access_token"]
    else:
        token = client.post("/api/auth/login", data={
            "username": "analysis_test",
            "password": "a-long-test-password-123",
        }).json()["access_token"]
    response = client.post("/api/analysis", json={"module_id": "histopathology"},
                           headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 503
    assert response.json()["detail"]["code"] == "model_or_pipeline_unavailable"

def test_csv_analysis_returns_descriptive_summary():
    response = client.post("/api/csv/analyze", files={
        "file": ("observations.csv", "age,group,score\n30,A,2\n40,B,4\n, A,6\n", "text/csv")
    })
    assert response.status_code == 200, response.text
    data = response.json()
    assert data["analysis_type"] == "descriptive_statistics"
    assert data["shape"] == {"rows": 3, "columns": 3}
    assert data["columns"][0]["dtype"].startswith("float")
    assert data["columns"][0]["missing"] == 1
    assert data["descriptive_statistics"]["score"]["mean"] == 4
    assert data["chart_data"]["categorical"][0]["column"] == "group"

def test_csv_upload_rejects_wrong_type_and_malformed_data():
    wrong_type = client.post("/api/csv/analyze", files={"file": ("data.txt", "x\n1\n", "text/plain")})
    assert wrong_type.status_code == 415
    malformed = client.post("/api/csv/analyze", files={"file": ("data.csv", "a,b\n1,2,3\n", "text/csv")})
    assert malformed.status_code == 400

def test_csv_upload_rejects_oversize_file():
    response = client.post("/api/csv/analyze", files={
        "file": ("large.csv", b"x" * (10 * 1024 * 1024 + 1), "text/csv")
    })
    assert response.status_code == 413

def test_histopathology_model_endpoint_is_honest_when_unconfigured(monkeypatch):
    monkeypatch.setattr(settings, "research_model_python", None)
    monkeypatch.setattr(settings, "histopathology_checkpoint", None)
    response = client.post("/api/research/histopathology/predict", files={
        "file": ("sample.png", b"not-an-image", "image/png"),
    })
    assert response.status_code == 503
    assert response.json()["detail"]["code"] == "research_model_unavailable"
    assert response.json()["detail"]["clinical_use"] is False

def test_histopathology_model_endpoint_rejects_unsupported_file(monkeypatch, tmp_path):
    configured_path = tmp_path / "python.exe"
    configured_checkpoint = tmp_path / "model.pt"
    configured_path.write_bytes(b"configured for endpoint validation")
    configured_checkpoint.write_bytes(b"configured for endpoint validation")
    monkeypatch.setattr(settings, "research_model_python", str(configured_path))
    monkeypatch.setattr(settings, "histopathology_checkpoint", str(configured_checkpoint))
    response = client.post("/api/research/histopathology/predict", files={
        "file": ("sample.csv", b"x,y\n1,2\n", "text/csv"),
    })
    assert response.status_code == 415

def test_imaging_review_returns_only_raster_metadata():
    from io import BytesIO
    from PIL import Image

    image_buffer = BytesIO()
    Image.new("RGB", (32, 24), color="white").save(image_buffer, format="PNG")
    response = client.post("/api/imaging/inspect", data={"module_id": "ct"}, files={
        "file": ("sample.png", image_buffer.getvalue(), "image/png"),
    })
    assert response.status_code == 200, response.text
    result = response.json()
    assert result["inspection_type"] == "raster_image_metadata"
    assert result["metadata"]["width"] == 32
    assert result["metadata"]["height"] == 24
    assert result["modality_check"] == "not_verifiable_from_raster_image"
    assert result["patient_identifiers_returned"] is False
    assert result["model_inference_performed"] is False

def test_imaging_review_rejects_unsupported_files():
    response = client.post("/api/imaging/inspect", data={"module_id": "mri"}, files={
        "file": ("scan.nii", b"not-supported", "application/octet-stream"),
    })
    assert response.status_code == 415
