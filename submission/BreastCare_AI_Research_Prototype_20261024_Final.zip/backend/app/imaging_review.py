from __future__ import annotations

from io import BytesIO

from PIL import Image, UnidentifiedImageError


MAX_IMAGE_PIXELS = 100_000_000
EXPECTED_MODALITIES = {
    "ct": {"CT"},
    "mri": {"MR"},
    "xray": {"CR", "DX", "MG"},
}
RASTER_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff"}
DICOM_EXTENSIONS = {".dcm", ".dicom"}


class ImagingReviewError(ValueError):
    pass


class ImagingReviewUnavailableError(RuntimeError):
    pass


def inspect_imaging_input(module_id: str, filename: str, content: bytes) -> dict:
    """Inspect one image/header without saving it or returning patient identifiers."""
    if module_id not in EXPECTED_MODALITIES:
        raise ImagingReviewError("Choose CT, MRI, or X-ray & Mammography for input review.")
    if not content:
        raise ImagingReviewError("The selected file is empty.")
    extension = "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if extension in RASTER_EXTENSIONS:
        try:
            with Image.open(BytesIO(content)) as image:
                if image.width * image.height > MAX_IMAGE_PIXELS:
                    raise ImagingReviewError("The image dimensions exceed the supported limit.")
                image_format = image.format
                width, height, mode = image.width, image.height, image.mode
                image.verify()
                return {
                    "inspection_type": "raster_image_metadata",
                    "module_id": module_id,
                    "modality_check": "not_verifiable_from_raster_image",
                    "metadata": {
                        "format": image_format,
                        "width": int(width),
                        "height": int(height),
                        "mode": mode,
                    },
                    "patient_identifiers_returned": False,
                    "model_inference_performed": False,
                }
        except ImagingReviewError:
            raise
        except (UnidentifiedImageError, Image.DecompressionBombError, OSError, ValueError) as exc:
            raise ImagingReviewError("The selected file is not a readable PNG, JPG, or TIFF image.") from exc
    if extension not in DICOM_EXTENSIONS:
        raise ImagingReviewError("Upload a single DICOM (.dcm/.dicom), PNG, JPG, JPEG, or TIFF image.")
    try:
        import pydicom

        dataset = pydicom.dcmread(BytesIO(content), stop_before_pixels=True, force=False)
    except ImportError as exc:
        raise ImagingReviewUnavailableError("DICOM header reading is unavailable. Install the project's backend requirements.") from exc
    except Exception as exc:
        raise ImagingReviewError("The DICOM file could not be read. Check that it is a valid single-instance DICOM file.") from exc

    modality = str(getattr(dataset, "Modality", "")).upper()
    if modality not in EXPECTED_MODALITIES[module_id]:
        expected = ", ".join(sorted(EXPECTED_MODALITIES[module_id]))
        found = modality or "unspecified"
        raise ImagingReviewError(f"This module expects DICOM modality {expected}; the uploaded file reports {found}.")

    def safe_int(name: str):
        value = getattr(dataset, name, None)
        try:
            return int(value) if value is not None else None
        except (TypeError, ValueError):
            return None

    def safe_numbers(name: str):
        value = getattr(dataset, name, None)
        if value is None:
            return None
        try:
            if isinstance(value, (str, bytes)):
                return [float(value)]
            try:
                return [float(item) for item in value]
            except TypeError:
                return [float(value)]
        except (TypeError, ValueError):
            return None

    metadata = {
        "modality": modality,
        "rows": safe_int("Rows"),
        "columns": safe_int("Columns"),
        "frames": safe_int("NumberOfFrames") or 1,
        "samples_per_pixel": safe_int("SamplesPerPixel"),
        "pixel_spacing_mm": safe_numbers("PixelSpacing"),
        "slice_thickness_mm": safe_numbers("SliceThickness"),
    }
    return {
        "inspection_type": "dicom_header_metadata",
        "module_id": module_id,
        "modality_check": "matches_selected_module",
        "metadata": metadata,
        "patient_identifiers_returned": False,
        "model_inference_performed": False,
        "note": "Single-instance header inspection only. Pixel data and patient-identifying DICOM fields are not returned.",
    }
