import io
import math

import pandas as pd


def analyze_csv(content: bytes) -> dict:
    """Parse a bounded CSV payload and return JSON-safe descriptive summaries."""
    frame = None
    errors = []
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            frame = pd.read_csv(io.BytesIO(content), encoding=encoding, sep=None,
                                engine="python", on_bad_lines="error")
            break
        except UnicodeDecodeError as exc:
            errors.append(exc)
        except pd.errors.EmptyDataError:
            raise ValueError("The CSV file is empty or has no header row.")
        except pd.errors.ParserError as exc:
            raise ValueError(f"Could not parse CSV structure: {exc}") from exc
    if frame is None:
        raise ValueError("Could not decode this CSV file using common text encodings.") from errors[-1]
    if frame.empty and len(frame.columns) == 0:
        raise ValueError("The CSV file has no columns.")
    if len(frame.columns) == 0:
        raise ValueError("The CSV file has no columns.")

    columns = [str(c) for c in frame.columns]
    missing = frame.isna().sum()
    numeric = frame.select_dtypes(include="number")
    stats = {}
    for column in numeric.columns:
        values = numeric[column].dropna()
        stats[str(column)] = {
            "count": int(values.count()),
            "mean": _number(values.mean()), "std": _number(values.std()),
            "min": _number(values.min()), "q25": _number(values.quantile(.25)),
            "median": _number(values.median()), "q75": _number(values.quantile(.75)),
            "max": _number(values.max()),
        }
    chart_data = {
        "numeric": [{"column": col, **values} for col, values in stats.items()],
        "categorical": [],
    }
    for column in frame.columns:
        if column in numeric.columns:
            continue
        counts = frame[column].fillna("(missing)").astype(str).value_counts().head(20)
        chart_data["categorical"].append({
            "column": str(column),
            "counts": [{"label": str(label), "count": int(count)} for label, count in counts.items()],
        })
    return {
        "shape": {"rows": int(frame.shape[0]), "columns": int(frame.shape[1])},
        "columns": [{"name": str(col), "dtype": str(frame[col].dtype),
                     "missing": int(missing[col]),
                     "missing_percent": round(float(missing[col] / max(len(frame), 1) * 100), 2)}
                    for col in frame.columns],
        "descriptive_statistics": stats,
        "chart_data": chart_data,
    }


def _number(value):
    if pd.isna(value) or not math.isfinite(float(value)):
        return None
    return float(value)
