import base64
import json
import logging
import subprocess
from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, HTTPException, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from .catalog import MODULES
from .config import settings
from .database import Base, engine, get_db
from .models import User
from .schemas import AnalysisRequest, RegisterRequest, TokenResponse, UserResponse
from .security import create_access_token, decode_access_token, hash_password, verify_password
from .csv_analysis import analyze_csv
from .imaging_review import inspect_imaging_input, ImagingReviewError, ImagingReviewUnavailableError
from .report_extraction import extract_report, ReportExtractionError, OCRUnavailableError

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.app_name,
    version="0.1.0",
    description="Local-first BreastCare AI research platform. Optional histopathology model outputs and imaging metadata reviews are research-only; CSV analysis is descriptive and reports are text-extracted only.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin, "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")
MAX_CSV_BYTES = 10 * 1024 * 1024
MAX_REPORT_BYTES = 10 * 1024 * 1024
MAX_HISTOPATHOLOGY_BYTES = 10 * 1024 * 1024
MAX_IMAGING_BYTES = 10 * 1024 * 1024
logger = logging.getLogger(__name__)

@app.get("/api/health")
def health():
    return {"status": "ok", "app": settings.app_name, "phase": "research-prototype", "database": "configured"}

@app.get("/api/modules")
def list_modules():
    modules = [dict(module) for module in MODULES]
    python_path = Path(settings.research_model_python).expanduser() if settings.research_model_python else None
    checkpoint_path = Path(settings.histopathology_checkpoint).expanduser() if settings.histopathology_checkpoint else None
    model_ready = bool(python_path and python_path.is_file() and checkpoint_path and checkpoint_path.is_file())
    if model_ready:
        histopathology = next(module for module in modules if module["id"] == "histopathology")
        histopathology["status"] = "research_model_configured"
        histopathology["description"] = "Optional local BreaKHis ResNet-18 research model; not for diagnosis or clinical use."
    return {"modules": modules}

@app.post("/api/auth/register", response_model=UserResponse, status_code=201)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    email = str(payload.email).lower()
    username = payload.username.strip()
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(status_code=409, detail="An account with this email already exists.")
    if db.query(User).filter(User.username == username).first():
        raise HTTPException(status_code=409, detail="This username is already taken.")
    user = User(email=email, username=username, password_hash=hash_password(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return UserResponse(id=user.id, email=user.email, username=user.username)

@app.post("/api/auth/login", response_model=TokenResponse)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    identity = form.username.strip()
    user = db.query(User).filter(
        (User.email == identity.lower()) | (User.username == identity)
    ).first()
    if not user or not verify_password(form.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid username/email or password.")
    return TokenResponse(
        access_token=create_access_token(user.id),
        expires_in=settings.token_ttl_hours * 3600,
    )

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    user_id = decode_access_token(token)
    if user_id is None:
        raise HTTPException(status_code=401, detail="Invalid or expired access token.")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=401, detail="Account no longer exists.")
    return user

@app.get("/api/auth/me", response_model=UserResponse)
def me(user: User = Depends(get_current_user)):
    return UserResponse(id=user.id, email=user.email, username=user.username)

@app.post("/api/analysis")
def create_analysis(payload: AnalysisRequest, user: User = Depends(get_current_user)):
    module = next((m for m in MODULES if m["id"] == payload.module_id), None)
    if module is None:
        raise HTTPException(status_code=422, detail="Unknown module_id.")
    # Phase 1 deliberately does not fabricate inference. The endpoint is a truthful readiness check.
    raise HTTPException(
        status_code=503,
        detail={
            "code": "model_or_pipeline_unavailable",
            "message": "This endpoint does not provide inference. Use the module's implemented descriptive workflow or configure a compatible research model where available.",
            "module_id": payload.module_id,
            "module_status": module["status"],
            "next_step": "Install or implement a compatible pipeline and validated model before requesting analysis.",
        },
    )


@app.post("/api/research/histopathology/predict")
def predict_histopathology(file: UploadFile = File(...), explain: bool = Form(False)):
    """Run an optional local BreaKHis research checkpoint. This is not diagnostic."""
    python_path = Path(settings.research_model_python).expanduser() if settings.research_model_python else None
    checkpoint_path = Path(settings.histopathology_checkpoint).expanduser() if settings.histopathology_checkpoint else None
    if not python_path or not python_path.is_file() or not checkpoint_path or not checkpoint_path.is_file():
        raise HTTPException(
            status_code=503,
            detail={
                "code": "research_model_unavailable",
                "message": "Configure a compatible local PyTorch Python environment and BreaKHis checkpoint to enable this research workflow.",
                "clinical_use": False,
            },
        )
    filename = (file.filename or "").strip()
    suffix = Path(filename).suffix.lower()
    accepted_types = {
        ".png": {"image/png", "application/octet-stream"},
        ".jpg": {"image/jpeg", "application/octet-stream"},
        ".jpeg": {"image/jpeg", "application/octet-stream"},
        ".tif": {"image/tiff", "application/octet-stream"},
        ".tiff": {"image/tiff", "application/octet-stream"},
    }
    if suffix not in accepted_types:
        raise HTTPException(status_code=415, detail="Upload a PNG, JPG, JPEG, or TIFF histopathology image.")
    if file.content_type not in (None, "", *accepted_types[suffix]):
        raise HTTPException(status_code=415, detail="The uploaded content type does not match the image extension.")
    content = file.file.read(MAX_HISTOPATHOLOGY_BYTES + 1)
    file.file.close()
    if not content:
        raise HTTPException(status_code=400, detail="The image file is empty.")
    if len(content) > MAX_HISTOPATHOLOGY_BYTES:
        raise HTTPException(status_code=413, detail="Image files must be 10 MB or smaller.")
    try:
        from PIL import Image, UnidentifiedImageError
        from io import BytesIO
        with Image.open(BytesIO(content)) as image:
            if image.width * image.height > 100_000_000:
                raise HTTPException(status_code=413, detail="The image dimensions exceed the supported limit.")
            image.verify()
    except HTTPException:
        raise
    except (UnidentifiedImageError, Image.DecompressionBombError, OSError, ValueError) as exc:
        raise HTTPException(status_code=400, detail="The selected file is not a readable PNG, JPG, or TIFF image.") from exc

    worker_path = Path(__file__).with_name("research_model_worker.py")
    payload = json.dumps({"image_base64": base64.b64encode(content).decode("ascii"), "explain": explain})
    try:
        completed = subprocess.run(
            [str(python_path), str(worker_path), str(checkpoint_path)],
            input=payload,
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(status_code=504, detail="The local research model took too long to respond.") from exc
    except OSError as exc:
        logger.exception("Could not start the configured research model worker")
        raise HTTPException(status_code=503, detail="Could not start the configured local research model environment.") from exc
    if completed.returncode != 0:
        logger.error("Research model worker failed: %s", completed.stderr[-2000:])
        try:
            worker_error = json.loads(completed.stdout).get("error")
        except (json.JSONDecodeError, AttributeError):
            worker_error = None
        raise HTTPException(status_code=503, detail=worker_error or "The research model could not process this image.")
    try:
        result = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        logger.error("Research model worker returned invalid output: %s", completed.stdout[-1000:])
        raise HTTPException(status_code=503, detail="The research model returned an unreadable response.") from exc
    return {"filename": filename, "size_bytes": len(content), "analysis_type": "research_only_model_output", **result}


@app.post("/api/imaging/inspect")
def inspect_imaging_upload(module_id: str = Form(...), file: UploadFile = File(...)):
    """Inspect one radiology image or DICOM header. No pixel inference or diagnosis is performed."""
    if module_id not in {"ct", "mri", "xray"}:
        raise HTTPException(status_code=422, detail="module_id must be ct, mri, or xray.")
    filename = (file.filename or "").strip()
    suffix = Path(filename).suffix.lower()
    accepted_types = {
        ".dcm": {"application/dicom", "application/octet-stream"},
        ".dicom": {"application/dicom", "application/octet-stream"},
        ".png": {"image/png", "application/octet-stream"},
        ".jpg": {"image/jpeg", "application/octet-stream"},
        ".jpeg": {"image/jpeg", "application/octet-stream"},
        ".tif": {"image/tiff", "application/octet-stream"},
        ".tiff": {"image/tiff", "application/octet-stream"},
    }
    if suffix not in accepted_types:
        raise HTTPException(status_code=415, detail="Upload one DICOM, PNG, JPG, JPEG, or TIFF image.")
    if file.content_type not in (None, "", *accepted_types[suffix]):
        raise HTTPException(status_code=415, detail="The uploaded content type does not match the file extension.")
    content = file.file.read(MAX_IMAGING_BYTES + 1)
    file.file.close()
    if not content:
        raise HTTPException(status_code=400, detail="The selected image is empty.")
    if len(content) > MAX_IMAGING_BYTES:
        raise HTTPException(status_code=413, detail="Imaging files must be 10 MB or smaller.")
    try:
        result = inspect_imaging_input(module_id, filename, content)
    except ImagingReviewUnavailableError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ImagingReviewError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"size_bytes": len(content), **result}

@app.post("/api/csv/analyze")
async def analyze_csv_upload(file: UploadFile = File(...)):
    """Analyze tabular data descriptively. No prediction or diagnosis is performed."""
    filename = (file.filename or "").strip()
    if not filename.lower().endswith(".csv"):
        raise HTTPException(status_code=415, detail="Upload a .csv file.")
    if file.content_type not in (None, "", "text/csv", "application/csv", "application/vnd.ms-excel", "text/plain", "application/octet-stream"):
        raise HTTPException(status_code=415, detail="The uploaded file must have a CSV-compatible content type.")
    content = await file.read(MAX_CSV_BYTES + 1)
    await file.close()
    if not content:
        raise HTTPException(status_code=400, detail="The CSV file is empty.")
    if len(content) > MAX_CSV_BYTES:
        raise HTTPException(status_code=413, detail="CSV files must be 10 MB or smaller.")
    try:
        result = analyze_csv(content)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"filename": filename, "size_bytes": len(content), "analysis_type": "descriptive_statistics", **result}


@app.post("/api/reports/extract")
def extract_report_upload(file: UploadFile = File(...)):
    """Extract readable text from PDFs or images; this endpoint does not interpret content."""
    filename = (file.filename or "").strip()
    suffix = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""
    allowed_types = {"pdf": {"application/pdf", "application/octet-stream"},
                     "png": {"image/png", "application/octet-stream"},
                     "jpg": {"image/jpeg", "application/octet-stream"},
                     "jpeg": {"image/jpeg", "application/octet-stream"},
                     "tif": {"image/tiff", "application/octet-stream"},
                     "tiff": {"image/tiff", "application/octet-stream"},
                     "bmp": {"image/bmp", "image/x-ms-bmp", "application/octet-stream"}}
    if suffix not in allowed_types:
        raise HTTPException(status_code=415, detail="Upload a PDF, PNG, JPG, JPEG, TIFF, or BMP file.")
    if file.content_type not in (None, "", *allowed_types[suffix]):
        raise HTTPException(status_code=415, detail="The uploaded content type does not match a supported report file.")
    content = file.file.read(MAX_REPORT_BYTES + 1)
    file.file.close()
    if not content:
        raise HTTPException(status_code=400, detail="The report file is empty.")
    if len(content) > MAX_REPORT_BYTES:
        raise HTTPException(status_code=413, detail="Report files must be 10 MB or smaller.")
    try:
        result = extract_report(filename, content)
    except OCRUnavailableError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ReportExtractionError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"filename": filename, "size_bytes": len(content), "extraction_type": "text_extraction",
            "character_count": len(result["text"]), **result}
