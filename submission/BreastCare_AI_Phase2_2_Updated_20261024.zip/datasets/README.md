# Dataset setup

No patient datasets are included. Use datasets you are authorized to access and process. Record provenance, licensing, label definitions, patient identifiers where permitted, and train/validation/test split strategy. Synthetic fixtures may be used to test software but must never be presented as clinical evidence.
