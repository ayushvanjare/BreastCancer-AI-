# BreastCare AI project milestones

This document describes what the current source package actually implements. It separates working software from research capabilities that still need suitable data, model weights, or validation evidence.

| Milestone | Status | Delivered |
|---|---|---|
| Local application foundation | Complete | React/TypeScript dashboard, FastAPI API, SQLite account endpoints, Windows launch scripts, module registry, local settings, and API documentation. |
| CSV exploration | Complete | Bounded in-memory upload, robust text decoding and pandas parsing, dimensions, column types, missing values, descriptive statistics, and chart-ready category counts. This is not clinical prediction. |
| Report text extraction | Complete | In-memory PDF/image extraction, embedded PDF text and optional local Tesseract OCR, with size/page limits and human-review warnings. No medical interpretation. |
| BreaKHis research experiment | Complete as a baseline | ResNet-18 training script, five official folds at four magnifications, group-separated validation, metrics/checkpoints generated outside the source archive, and a results summary. |
| BACH external evaluation | Complete as a research evaluation | 400-image external evaluation using the original four classes and a documented binary grouping. Mean accuracy was about 49–52% with poor non-carcinoma specificity, indicating weak transfer in this setup. |
| Optional histopathology demonstration | Implemented; requires local assets | Research-only ResNet-18 inference and optional Grad-CAM in an isolated local worker. Requires a compatible checkpoint and an existing PyTorch/torchvision environment; neither is bundled. Do not use on patient images. |
| CT/MRI/X-ray input review | Complete as metadata review only | Single raster/DICOM/NIfTI header review plus same-series DICOM consistency checks; pixel/voxel data are not analyzed and no prediction is produced. |
| Modality-specific medical prediction | Not complete | No compatible licensed CT/MRI/X-ray/mammography datasets or trained checkpoints were supplied. Creating only a screen or using the histopathology model for these modalities would be misleading. |
| BRCA mutation prediction | Not complete | Requires a suitable labeled genomics dataset, a defined task, and independent evaluation. |
| Account-protected encrypted analysis history | Implemented for local research use | Upload endpoints require a bearer token. Original uploads and results are encrypted in the local database, scoped to the signed-in account, and can be viewed, downloaded, or deleted. The local key must be kept private; this is not clinical-grade storage. |
| Patient-care safeguards | Local-prototype safeguards implemented | Upload workflows require sign-in, modality review never infers from image pixels, and UI/API output explicitly says research-only or metadata-only. No emergency, diagnosis, or treatment advice is provided. This does not make the app safe for patient care. |
| Production deployment and clinical safeguards | Not complete | No public deployment, clinical-grade privacy/security controls, audit program, or clinical validation is provided. Do not use identifiable patient data or expose this prototype publicly. |

## Before demonstrating

1. Install Node.js 20 LTS or newer and Python 3.11/3.12; reopen VS Code after installing Node.js so its terminal refreshes `PATH`.
2. Follow `README.md` to install the backend and frontend dependencies and start each service.
3. Confirm `http://127.0.0.1:8000/docs` and `http://localhost:5173` open.
4. In the dashboard, demonstrate CSV descriptive analysis and report text extraction with non-sensitive example files. Demonstrate imaging metadata review with a sample file only if available.
5. Show the BreaKHis/BACH results and explain that BACH transfer was poor and neither experiment is clinical validation.
6. Configure the optional histopathology worker only if the compatible local checkpoint and CUDA Python environment are available. Keep the source ZIP free of datasets, checkpoints, `.env`, `.history.key`, and virtual environments. Keep the local encryption key private and separately backed up if you need saved history.

## Research and safety boundary

No displayed score is a diagnosis, risk estimate, screening result, or recommendation. Do not upload patient records or use the application to guide care. BACH use must follow the dataset permission and attribution terms reported by the project owner.
