"""Encrypted local storage for account-scoped research analysis history."""
from __future__ import annotations

import json
import os
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

KEY_PATH = Path(__file__).resolve().parents[1] / ".history.key"


class HistoryStorageError(RuntimeError):
    pass


def _fernet() -> Fernet:
    """Load or atomically create a local key, excluded from source control."""
    KEY_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(KEY_PATH, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        key = KEY_PATH.read_bytes().strip()
    else:
        key = Fernet.generate_key()
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(key)
        try:
            os.chmod(KEY_PATH, 0o600)
        except OSError:
            pass
    try:
        return Fernet(key)
    except (TypeError, ValueError) as exc:
        raise HistoryStorageError("The local history encryption key is invalid. Restore the ignored .history.key file or clear the local history database.") from exc


def encrypt_bytes(value: bytes) -> bytes:
    return _fernet().encrypt(value)


def decrypt_bytes(value: bytes) -> bytes:
    try:
        return _fernet().decrypt(value)
    except InvalidToken as exc:
        raise HistoryStorageError("This history entry cannot be decrypted with the current local key.") from exc


def encrypt_json(value: dict) -> bytes:
    return encrypt_bytes(json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8"))


def decrypt_json(value: bytes) -> dict:
    try:
        result = json.loads(decrypt_bytes(value))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise HistoryStorageError("The saved analysis result is damaged or unreadable.") from exc
    if not isinstance(result, dict):
        raise HistoryStorageError("The saved analysis result has an invalid format.")
    return result
