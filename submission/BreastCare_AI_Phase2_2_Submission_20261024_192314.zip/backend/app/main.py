from fastapi import Depends, FastAPI, File, HTTPException, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from .catalog import MODULES
from .config import settings
from .database import Base, engine, get_db
from .models import User
from .schemas import AnalysisRequest, RegisterRequest, TokenResponse, UserResponse
from .security import create_access_token, decode_access_token, hash_password, verify_password
from .csv_analysis import analyze_csv
from .report_extraction import extract_report, ReportExtractionError, OCRUnavailableError

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.app_name,
    version="0.1.0",
    description="Local-first BreastCare AI research platform. Medical models are not bundled; CSV analysis is descriptive and reports are text-extracted only.",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin, "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")
MAX_CSV_BYTES = 10 * 1024 * 1024
MAX_REPORT_BYTES = 10 * 1024 * 1024

@app.get("/api/health")
def health():
    return {"status": "ok", "app": settings.app_name, "phase": "2.2", "database": "configured"}

@app.get("/api/modules")
def list_modules():
    return {"modules": MODULES}

@app.post("/api/auth/register", response_model=UserResponse, status_code=201)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    email = str(payload.email).lower()
    username = payload.username.strip()
    if db.query(User).filter(User.email == email).first():
        raise HTTPException(status_code=409, detail="An account with this email already exists.")
    if db.query(User).filter(User.username == username).first():
        raise HTTPException(status_code=409, detail="This username is already taken.")
    user = User(email=email, username=username, password_hash=hash_password(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return UserResponse(id=user.id, email=user.email, username=user.username)

@app.post("/api/auth/login", response_model=TokenResponse)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    identity = form.username.strip()
    user = db.query(User).filter(
        (User.email == identity.lower()) | (User.username == identity)
    ).first()
    if not user or not verify_password(form.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid username/email or password.")
    return TokenResponse(
        access_token=create_access_token(user.id),
        expires_in=settings.token_ttl_hours * 3600,
    )

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    user_id = decode_access_token(token)
    if user_id is None:
        raise HTTPException(status_code=401, detail="Invalid or expired access token.")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=401, detail="Account no longer exists.")
    return user

@app.get("/api/auth/me", response_model=UserResponse)
def me(user: User = Depends(get_current_user)):
    return UserResponse(id=user.id, email=user.email, username=user.username)

@app.post("/api/analysis")
def create_analysis(payload: AnalysisRequest, user: User = Depends(get_current_user)):
    module = next((m for m in MODULES if m["id"] == payload.module_id), None)
    if module is None:
        raise HTTPException(status_code=422, detail="Unknown module_id.")
    # Phase 1 deliberately does not fabricate inference. The endpoint is a truthful readiness check.
    raise HTTPException(
        status_code=503,
        detail={
            "code": "model_or_pipeline_unavailable",
            "message": "This module's processing pipeline and/or compatible model is not implemented in Phase 1.",
            "module_id": payload.module_id,
            "module_status": module["status"],
            "next_step": "Install or implement a compatible pipeline and validated model before requesting analysis.",
        },
    )

@app.post("/api/csv/analyze")
async def analyze_csv_upload(file: UploadFile = File(...)):
    """Analyze tabular data descriptively. No prediction or diagnosis is performed."""
    filename = (file.filename or "").strip()
    if not filename.lower().endswith(".csv"):
        raise HTTPException(status_code=415, detail="Upload a .csv file.")
    if file.content_type not in (None, "", "text/csv", "application/csv", "application/vnd.ms-excel", "text/plain", "application/octet-stream"):
        raise HTTPException(status_code=415, detail="The uploaded file must have a CSV-compatible content type.")
    content = await file.read(MAX_CSV_BYTES + 1)
    await file.close()
    if not content:
        raise HTTPException(status_code=400, detail="The CSV file is empty.")
    if len(content) > MAX_CSV_BYTES:
        raise HTTPException(status_code=413, detail="CSV files must be 10 MB or smaller.")
    try:
        result = analyze_csv(content)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"filename": filename, "size_bytes": len(content), "analysis_type": "descriptive_statistics", **result}


@app.post("/api/reports/extract")
def extract_report_upload(file: UploadFile = File(...)):
    """Extract readable text from PDFs or images; this endpoint does not interpret content."""
    filename = (file.filename or "").strip()
    suffix = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""
    allowed_types = {"pdf": {"application/pdf", "application/octet-stream"},
                     "png": {"image/png", "application/octet-stream"},
                     "jpg": {"image/jpeg", "application/octet-stream"},
                     "jpeg": {"image/jpeg", "application/octet-stream"},
                     "tif": {"image/tiff", "application/octet-stream"},
                     "tiff": {"image/tiff", "application/octet-stream"},
                     "bmp": {"image/bmp", "image/x-ms-bmp", "application/octet-stream"}}
    if suffix not in allowed_types:
        raise HTTPException(status_code=415, detail="Upload a PDF, PNG, JPG, JPEG, TIFF, or BMP file.")
    if file.content_type not in (None, "", *allowed_types[suffix]):
        raise HTTPException(status_code=415, detail="The uploaded content type does not match a supported report file.")
    content = file.file.read(MAX_REPORT_BYTES + 1)
    file.file.close()
    if not content:
        raise HTTPException(status_code=400, detail="The report file is empty.")
    if len(content) > MAX_REPORT_BYTES:
        raise HTTPException(status_code=413, detail="Report files must be 10 MB or smaller.")
    try:
        result = extract_report(filename, content)
    except OCRUnavailableError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except ReportExtractionError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"filename": filename, "size_bytes": len(content), "extraction_type": "text_extraction",
            "character_count": len(result["text"]), **result}
