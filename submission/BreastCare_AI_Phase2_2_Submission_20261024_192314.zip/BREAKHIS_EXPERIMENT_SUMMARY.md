# BreaKHis ResNet-18 Baseline Experiment

## Scope

This is a research-only experiment on the public BreaKHis image dataset. It is not a diagnostic tool, clinical validation, or suitable for patient-care decisions.

## Setup

- Binary labels: benign and malignant.
- Model: ImageNet-pretrained ResNet-18; early layers frozen, layer 4 and classifier fine-tuned.
- Magnifications: 40X, 100X, 200X, and 400X, evaluated separately.
- Image size: 128 x 128.
- Maximum epochs: 8; early stopping based on validation loss with patience 2.
- For each official fold, the official test partition was held out. A group-separated validation set was created from the official training partition. Each run reported zero shared sample groups between fit, validation, and test.
- GPU: NVIDIA GeForce RTX 3050 Laptop GPU using the existing CUDA-enabled PyTorch environment.
- Metrics below are simple arithmetic means of the five fold-level metrics, not pooled counts.

## Mean results across five fold runs

| Magnification | Accuracy | Malignant recall | Benign specificity | Balanced accuracy |
|---|---:|---:|---:|---:|
| 40X | 77.0% | 82.9% | 65.4% | 74.1% |
| 100X | 77.2% | 83.7% | 64.4% | 74.1% |
| 200X | 81.4% | 82.9% | 78.1% | 80.5% |
| 400X | 81.3% | 83.0% | 78.2% | 80.6% |

## Fold-level ranges

| Magnification | Accuracy range | Malignant recall range | Benign specificity range |
|---|---:|---:|---:|
| 40X | 72.1–80.7% | 76.7–89.5% | 43.3–76.6% |
| 100X | 73.6–80.8% | 72.5–92.1% | 46.9–75.5% |
| 200X | 75.8–84.5% | 70.2–88.8% | 64.9–86.1% |
| 400X | 76.9–84.7% | 79.2–86.8% | 71.6–86.6% |

## Interpretation

The 200X and 400X runs had higher mean accuracy and specificity than the 40X and 100X runs in this experiment. Their averages are nearly identical; the results do not establish a reliable winning magnification. Fold-level variation remains material. Several runs showed fit accuracy increasing while validation loss worsened, which is consistent with overfitting risk.

The five official test splits are not disjoint: the 40X test counts sum to 3,509, while each fold contains 1,995 40X images. Therefore, report the mean of fold-level metrics rather than treating all fold test predictions as 3,509 unique images or pooling them as one independent test set.

The earlier scratch CNN baseline at 40X had five-fold means of 65.8% accuracy, 68.4% malignant recall, 60.5% benign specificity, and 64.5% balanced accuracy. This is only an exploratory comparison: the scratch CNN used all official training images, while ResNet-18 reserved groups for validation.

## External dataset status

BACH microscopy images were downloaded and their folder structure was checked, but model evaluation has not been run. The dataset record lists a CC BY-NC-ND license and says the images cannot be changed. Clarification has been requested from the dataset organizers about in-memory resizing/normalization and reporting metrics. Do not preprocess or evaluate the BACH images until permitted use is clarified.

## Limitations and next work

- This is a small exploratory baseline with one random seed and no confidence intervals.
- It uses one dataset and one image magnification at a time; results do not establish performance on other hospitals, scanners, staining conditions, or patient populations.
- Do not tune thresholds or model settings using these test results. Further model selection should use training/validation data, followed by an independent external test set whose license permits the intended processing.
- Do not integrate this model into a patient-facing diagnostic workflow. Any future demo should be explicitly labeled research-only and prevent clinical interpretation.

## BreaKHis citation

Spanhol, F. A., Oliveira, L. S., Petitjean, C., and Heutte, L. “A Dataset for Breast Cancer Histopathological Image Classification.” IEEE Transactions on Biomedical Engineering, 2016. DOI: 10.1109/TBME.2015.2496264.
