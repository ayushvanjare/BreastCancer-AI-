import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { Link, NavLink, Route, Routes, useLocation, useNavigate, useParams } from "react-router-dom";
import {
  Activity, ArrowDownRight, ArrowRight, BrainCircuit, CheckCircle2,
  CircleHelp, ClipboardList, CloudDownload, Database, FileText, FlaskConical,
  HeartPulse, Image as ImageIcon, LayoutDashboard, LockKeyhole, Menu,
  Microscope, Scan, Search, Settings, ShieldCheck, Table2, Upload, UserRound, X, Zap,
} from "lucide-react";
import { API_BASE, analyzeCsv, extractReport, getHealth, getModules, type CsvAnalysisResult, type ReportExtractionResult } from "./api";
import type { ResearchModule } from "./types";

const iconMap: Record<string, typeof Microscope> = {
  Microscope, Scan, Activity, Image: ImageIcon, FileText, Table2,
};

function useModules() {
  const [modules, setModules] = useState<ResearchModule[]>([]);
  useEffect(() => {
    getModules().then(setModules).catch(() => setModules([
      { id: "histopathology", title: "Histopathology", subtitle: "Tissue image analysis", description: "Research workflow for tissue image analysis.", icon: "Microscope", input_types: ["PNG", "JPG"], status: "interface_ready_model_missing", accent: "teal" },
      { id: "ct", title: "CT Scan", subtitle: "Computed tomography", description: "CT series review and compatible model routing.", icon: "Scan", input_types: ["DICOM", "PNG"], status: "interface_ready_model_missing", accent: "blue" },
      { id: "mri", title: "MRI Analysis", subtitle: "Magnetic resonance imaging", description: "MRI series review and sequence-specific processing.", icon: "Activity", input_types: ["DICOM", "PNG"], status: "interface_ready_model_missing", accent: "purple" },
      { id: "xray", title: "X-ray & Mammography", subtitle: "Radiology image analysis", description: "Radiology input checks and compatible model routing.", icon: "Image", input_types: ["DICOM", "PNG", "JPG"], status: "interface_ready_model_missing", accent: "orange" },
      { id: "reports", title: "Doctor Reports", subtitle: "Prescription and report extraction", description: "Extract text from reports for human review. No medical interpretation is performed.", icon: "FileText", input_types: ["PDF", "PNG", "JPG"], status: "interface_ready_text_extraction", accent: "green" },
      { id: "csv", title: "CSV Analysis", subtitle: "Tabular data exploration", description: "Explore structure, missing values, and descriptive statistics without medical prediction.", icon: "Table2", input_types: ["CSV"], status: "interface_ready_descriptive_analysis", accent: "teal" },
    ]));
  }, []);
  return modules;
}

function Brand({ compact = false }: { compact?: boolean }) {
  return <Link to="/" className={`brand ${compact ? "brand-compact" : ""}`}>
    <span className="brand-mark"><HeartPulse size={22} strokeWidth={2.4} /></span>
    {!compact && <span className="brand-name">BreastCare <b>AI</b><small>RESEARCH SUITE</small></span>}
  </Link>;
}

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [health, setHealth] = useState<"checking" | "online" | "offline">("checking");
  const modules = useModules();
  const location = useLocation();

  useEffect(() => {
    getHealth().then(() => setHealth("online")).catch(() => setHealth("offline"));
  }, [location.pathname]);

  const filteredModules = modules.filter((m) => `${m.title} ${m.subtitle}`.toLowerCase().includes(query.toLowerCase()));

  return <div className="app-shell">
    {sidebarOpen && <button className="mobile-scrim" aria-label="Close navigation" onClick={() => setSidebarOpen(false)} />}
    <aside className={`sidebar ${sidebarOpen ? "sidebar-open" : ""}`}>
      <div className="sidebar-brand"><Brand /><button className="icon-button sidebar-close" onClick={() => setSidebarOpen(false)} aria-label="Close menu"><X size={18} /></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav className="nav-list">
        <NavLink to="/" end onClick={() => setSidebarOpen(false)} className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}><LayoutDashboard size={18} /> Dashboard</NavLink>
        <div className="nav-section-title">ANALYSIS MODULES</div>
        {modules.map((m) => {
          const Icon = iconMap[m.icon] ?? FlaskConical;
          return <NavLink key={m.id} to={`/modules/${m.id}`} onClick={() => setSidebarOpen(false)} className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}>
            <Icon size={18} /><span>{m.title}</span><span className="nav-dot" />
          </NavLink>;
        })}
        <div className="nav-section-title">RESEARCH</div>
        <NavLink to="/models" onClick={() => setSidebarOpen(false)} className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}><BrainCircuit size={18} /> Model registry</NavLink>
        <NavLink to="/results" onClick={() => setSidebarOpen(false)} className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}><FlaskConical size={18} /> Experiment results</NavLink>
        <NavLink to="/history" onClick={() => setSidebarOpen(false)} className={({ isActive }) => `nav-link ${isActive ? "active" : ""}`}><ClipboardList size={18} /> Analysis history</NavLink>
      </nav>
      <div className="sidebar-spacer" />
      <div className="offline-card">
        <div className="offline-card-icon"><ShieldCheck size={17} /></div>
        <div><strong>Local-first workspace</strong><p>Designed for private, local research.</p><span className={`connection-state ${health}`}><i />{health === "online" ? "API connected" : health === "offline" ? "API disconnected" : "Checking API…"}</span></div>
      </div>
      <div className="sidebar-footer"><NavLink to="/settings" className="nav-link"><Settings size={18} /> Settings</NavLink><span>Phase 2.2 · Data exploration</span></div>
    </aside>

    <main className="main-shell">
      <header className="topbar">
<div className="topbar-left">
  <button
    className="icon-button menu-toggle"
    aria-label="Open navigation"
    onClick={() => setSidebarOpen(true)}
  >
    <Menu size={21} />
  </button>

  <div className="breadcrumb">
    <span>Workspace</span>
    <span className="crumb-sep">/</span>
    <b>
      {location.pathname === "/"
        ? "Dashboard"
        : location.pathname
            .split("/")
            .filter(Boolean)
            .pop()
            ?.replace(/-/g, " ")}
    </b>
  </div>
</div>        <div className="topbar-actions">
          {searchOpen && <input autoFocus className="top-search" placeholder="Search modules…" value={query} onChange={(e) => setQuery(e.target.value)} />}
          <button className="icon-button" aria-label="Search modules" onClick={() => setSearchOpen(!searchOpen)}><Search size={19} /></button>
          <span className="topbar-divider" />
          <div className="local-pill"><span className={`status-dot ${health}`} /> Local environment</div>
          <div className="avatar"><UserRound size={18} /></div>
        </div>
      </header>
      <div className="page-wrap">
        <Routes>
          <Route path="/" element={<Dashboard modules={filteredModules} health={health} />} />
          <Route path="/modules/:moduleId" element={<ModulePage modules={modules} />} />
          <Route path="/models" element={<ModelsPage />} />
          <Route path="/results" element={<ExperimentResultsPage />} />
          <Route path="/history" element={<HistoryPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/login" element={<AuthPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
      <footer className="app-footer"><span>BreastCare AI <b>·</b> Research foundation</span><span><LockKeyhole size={13} /> Local-first by design</span></footer>
    </main>
  </div>;
}

function PageIntro({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return <div className="page-intro"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action}</div>;
}


function Dashboard({ modules, health }: { modules: ResearchModule[]; health: string }) {
  const [activeTab, setActiveTab] = useState("All modules");
  const [quickSearch, setQuickSearch] = useState("");
  const shown = modules.filter((m) => (activeTab === "All modules" || (activeTab === "Imaging" ? ["histopathology", "ct", "mri", "xray"].includes(m.id) : ["reports", "csv"].includes(m.id))) && `${m.title} ${m.subtitle}`.toLowerCase().includes(quickSearch.toLowerCase()));
  return <div className="page-content">
    <PageIntro eyebrow="RESEARCH WORKSPACE" title="Good to see you." description="Your multimodal breast cancer research workspace is ready to configure." action={<button className="button button-secondary" onClick={() => window.location.href = "/models"}><BrainCircuit size={16} /> Model registry <ArrowRight size={15} /></button>} />
    <section className="hero-panel">
      <div className="hero-copy"><div className="hero-kicker"><span className="hero-kicker-dot" /> MULTIMODAL AI RESEARCH PLATFORM</div><h2>Bring medical data<br /><em>into one workspace.</em></h2><p>Explore six dedicated analysis workflows, organize research inputs, and prepare your local AI environment.</p><div className="hero-actions"><Link to="/modules/histopathology" className="button button-white"><Upload size={16} /> Open image analysis <ArrowRight size={15} /></Link><Link to="/modules/csv" className="hero-text-link">Explore data analysis <ArrowDownRight size={15} /></Link></div><div className="hero-proof"><span><CheckCircle2 size={14} /> CPU-first architecture</span><span><CheckCircle2 size={14} /> Offline-ready foundation</span></div></div>
      <div className="hero-art" aria-hidden="true"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="orbit orbit-three" /><div className="hero-core"><HeartPulse size={42} /></div><div className="floating-chip chip-one"><Microscope size={17} /><span>Pathology</span></div><div className="floating-chip chip-two"><Database size={17} /><span>Research data</span></div><div className="floating-chip chip-three"><BrainCircuit size={17} /><span>AI models</span></div><div className="hero-art-caption">One platform. Modular workflows.</div></div>
    </section>
    <div className="stat-grid">
      <StatCard icon={<FlaskConical size={19} />} label="Analysis modules" value="06" note="Separate input workflows" tone="teal" />
      <StatCard icon={<BrainCircuit size={19} />} label="AI models installed" value="0" note="Add validated checkpoints" tone="purple" />
      <StatCard icon={<Database size={19} />} label="Datasets connected" value="0" note="Configure authorized data" tone="blue" />
      <StatCard icon={<Zap size={19} />} label="Runtime mode" value="CPU" note="GPU acceleration optional" tone="orange" />
    </div>
    <div className="section-heading"><div><div className="eyebrow">YOUR WORKSPACE</div><h2>Analysis modules</h2><p>Choose a workflow to see its supported inputs and setup status.</p></div><div className="section-tools"><div className="inline-search"><Search size={16} /><input value={quickSearch} onChange={(e) => setQuickSearch(e.target.value)} placeholder="Find a module" /></div></div></div>
    <div className="tabs" role="tablist" aria-label="Filter modules">{["All modules", "Imaging", "Documents & data"].map((tab) => <button key={tab} role="tab" aria-selected={activeTab === tab} className={`tab ${activeTab === tab ? "tab-active" : ""}`} onClick={() => setActiveTab(tab)}>{tab}</button>)}</div>
    <div className="module-grid">{shown.map((m) => <ModuleCard key={m.id} module={m} />)}</div>
    <div className="bottom-grid"><section className="surface-card readiness-card"><div className="card-title-row"><div><div className="eyebrow">ENVIRONMENT</div><h3>Local setup status</h3></div><span className={`badge ${health === "online" ? "badge-success" : "badge-neutral"}`}><span className="status-dot" />{health === "online" ? "Connected" : health === "offline" ? "API offline" : "Checking"}</span></div><div className="readiness-list"><ReadinessRow icon={<CheckCircle2 size={17} />} title="Frontend interface" detail="React application is running" done /><ReadinessRow icon={<CheckCircle2 size={17} />} title="Module navigation" detail="Six workflows registered" done /><ReadinessRow icon={<Database size={17} />} title="Database" detail="SQLite is created by the backend" done={health === "online"} /><ReadinessRow icon={<BrainCircuit size={17} />} title="Medical model weights" detail="Not bundled in Phase 1" done={false} /></div></section><section className="surface-card research-note"><div className="note-icon"><ShieldCheck size={20} /></div><div className="eyebrow">RESPONSIBLE AI</div><h3>Research first. Clinical claims only after validation.</h3><p>This foundation does not diagnose patients. Predictions will only be enabled when compatible models, weights, and evaluation evidence are available.</p><Link to="/models" className="text-link">Review model readiness <ArrowRight size={15} /></Link></section></div>
  </div>;
}


type ReadinessRowProps = {
  icon: React.ReactNode;
  title: string;
  detail: string;
  done?: boolean;
};

function ReadinessRow({
  icon,
  title,
  detail,
  done = false,
}: ReadinessRowProps) {
  return (
    <div className="readiness-row">
      <div className="readiness-icon">{icon}</div>

      <div className="readiness-content">
        <strong>{title}</strong>
        <span>{detail}</span>
      </div>

      <span className={`badge ${done ? "badge-success" : "badge-neutral"}`}>
        {done ? "Ready" : "Pending"}
      </span>
    </div>
  );
}


function StatCard({ icon, label, value, note, tone }: { icon: ReactNode; label: string; value: string; note: string; tone: string }) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-note">{note}</div></div>;
}
function ModuleCard({ module }: { module: ResearchModule }) {
  const Icon = iconMap[module.icon] ?? FlaskConical;
  const modelMissing = module.status === "interface_ready_model_missing";
  const featureReady = module.status === "interface_ready_text_extraction" || module.status === "interface_ready_descriptive_analysis";
  const badge = module.status === "interface_ready_text_extraction" ? "Text extraction" : module.status === "interface_ready_descriptive_analysis" ? "Descriptive analysis" : modelMissing ? "Model needed" : "Pipeline planned";
  return <Link to={`/modules/${module.id}`} className="module-card"><div className="module-card-top"><div className={`module-icon ${module.accent}`}><Icon size={21} /></div><span className={`badge ${modelMissing ? "badge-warning" : featureReady ? "badge-success" : "badge-neutral"}`}>{badge}</span></div><h3>{module.title}</h3><div className="module-subtitle">{module.subtitle}</div><p>{module.description}</p><div className="module-card-bottom"><span className="input-hint"><FileText size={14} /> {module.input_types.slice(0, 3).join(" · ")}</span><span className="card-arrow"><ArrowRight size={17} /></span></div></Link>;
}

function ModulePage({ modules }: { modules: ResearchModule[] }) {
  const { moduleId } = useParams();
  const module = modules.find((m) => m.id === moduleId);
  const Icon = iconMap[module?.icon ?? ""] ?? FlaskConical;
  const [file, setFile] = useState<File | null>(null);
  const [notice, setNotice] = useState("");
  const [task, setTask] = useState("research_review");
  const [csvResult, setCsvResult] = useState<CsvAnalysisResult | null>(null);
  const [csvBusy, setCsvBusy] = useState(false);
  const [reportResult, setReportResult] = useState<ReportExtractionResult | null>(null);
  const [reportBusy, setReportBusy] = useState(false);
  if (!module) return <NotFound />;
  const activeModule = module;
  const modelMissing = module.status === "interface_ready_model_missing";
  function handleFile(selected: File | undefined) {
    setNotice("");
    if (!selected) return;
    setFile(selected);
    setCsvResult(null);
    setReportResult(null);
    setNotice(activeModule.id === "csv" ? "CSV selected. Choose Analyze CSV to upload it for descriptive statistics." : activeModule.id === "reports" ? "Report selected. Choose Extract text to upload it for local text extraction." : "File selected for preview only. This workflow does not upload or analyze files yet.");
  }
  async function runCsvAnalysis() {
    if (!file) { setNotice("Select a CSV file first."); return; }
    setCsvBusy(true); setNotice(""); setCsvResult(null);
    try { setCsvResult(await analyzeCsv(file)); }
    catch (error) { setNotice(error instanceof Error ? error.message : "CSV analysis failed. Check the file and backend, then try again."); }
    finally { setCsvBusy(false); }
  }
  async function runReportExtraction() {
    if (!file) { setNotice("Select a report file first."); return; }
    setReportBusy(true); setNotice(""); setReportResult(null);
    try { setReportResult(await extractReport(file)); }
    catch (error) { setNotice(error instanceof Error ? error.message : "Text extraction failed. Check the file and backend, then try again."); }
    finally { setReportBusy(false); }
  }
  if (module.id === "csv") return <CsvWorkflow file={file} notice={notice} handleFile={handleFile} clearFile={() => { setFile(null); setCsvResult(null); setNotice(""); }} busy={csvBusy} result={csvResult} onAnalyze={runCsvAnalysis} />;
  if (module.id === "reports") return <ReportWorkflow module={module} file={file} notice={notice} handleFile={handleFile} clearFile={() => { setFile(null); setReportResult(null); setNotice(""); }} busy={reportBusy} result={reportResult} onExtract={runReportExtraction} />;
  return <div className="page-content">
    <div className="back-link"><Link to="/">← Back to dashboard</Link></div>
    <PageIntro eyebrow="ANALYSIS MODULE" title={module.title} description={module.description} action={<span className={`badge ${modelMissing ? "badge-warning" : "badge-neutral"}`}>{modelMissing ? "Compatible model required" : "Processing pipeline planned"}</span>} />
    <div className="module-detail-grid">
      <section className="surface-card upload-panel"><div className="card-title-row"><div><div className="eyebrow">INPUT WORKSPACE</div><h3>Prepare your input</h3></div><div className={`module-icon ${module.accent}`}><Icon size={21} /></div></div><p className="muted">Choose a file to preview the planned workflow. File processing will be implemented in a later phase.</p><label className="drop-zone"><input type="file" accept={module.id === "csv" ? ".csv,text/csv" : module.id === "reports" ? ".pdf,.png,.jpg,.jpeg" : ".png,.jpg,.jpeg,.tif,.tiff,.dcm,.nii,.nii.gz"} onChange={(e) => handleFile(e.target.files?.[0])} /><span className="upload-circle"><Upload size={21} /></span><strong>{file ? file.name : "Choose a file or drop it here"}</strong><span>{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB · local selection` : `Supported input examples: ${module.input_types.join(", ")}`}</span><span className="button button-secondary button-small">Browse files</span></label>{file && <div className="selected-file"><FileText size={18} /><div><strong>{file.name}</strong><span>{(file.size / 1024 / 1024).toFixed(2)} MB</span></div><button className="icon-button" onClick={() => { setFile(null); setNotice(""); }} aria-label="Remove selected file"><X size={16} /></button></div>}<div className="form-field"><label htmlFor="analysis-task">Research task</label><select id="analysis-task" value={task} onChange={(e) => setTask(e.target.value)}><option value="research_review">General research review</option><option value="quality_check">Input quality check (planned)</option><option value="model_inference">Model inference (requires model)</option></select></div>{notice && <div className="inline-notice"><CircleHelp size={16} />{notice}</div>}<button className="button button-primary full-width" onClick={() => setNotice(file ? "Phase 1 limitation: this page only previews the selected filename. Upload, processing and AI inference are not implemented yet." : "Select a file first. No files are sent to the backend in Phase 1.")}><FlaskConical size={16} /> Prepare analysis <ArrowRight size={15} /></button><p className="privacy-hint"><LockKeyhole size={13} /> Files remain in your browser in this Phase 1 interface.</p></section>
      <aside className="module-side-column"><section className="surface-card"><div className="eyebrow">MODULE READINESS</div><h3>{modelMissing ? "Model integration pending" : "Pipeline implementation pending"}</h3><p className="muted">{modelMissing ? "The interface is registered, but no compatible medical model weights are bundled." : "The interface is ready for the processing pipeline to be implemented."}</p><div className="status-row"><span>Interface</span><span className="status-value success"><CheckCircle2 size={14} /> Ready</span></div><div className="status-row"><span>Input processing</span><span className="status-value pending">Planned</span></div><div className="status-row"><span>Model weights</span><span className="status-value pending">Not installed</span></div></section><section className="surface-card"><div className="eyebrow">PLANNED WORKFLOW</div><div className="workflow-list"><WorkflowStep n="01" title="Validate input" text="Check file type and compatibility" /><WorkflowStep n="02" title="Preprocess" text="Apply modality-specific preparation" /><WorkflowStep n="03" title="Run analysis" text="Use a compatible model or processor" /><WorkflowStep n="04" title="Review output" text="Inspect results and limitations" /></div></section></aside>
    </div>
    <div className="medical-disclaimer"><ShieldCheck size={17} /><div><strong>Research software notice</strong><p>This Phase 1 foundation is not a medical device and does not diagnose cancer. Do not use it to make clinical decisions.</p></div></div>
  </div>;
}
function WorkflowStep({ n, title, text }: { n: string; title: string; text: string }) { return <div className="workflow-step"><span>{n}</span><div><strong>{title}</strong><p>{text}</p></div></div>; }

function CsvWorkflow({ file, notice, handleFile, clearFile, busy, result, onAnalyze }: {
  file: File | null; notice: string;
  handleFile: (file: File | undefined) => void; clearFile: () => void; busy: boolean;
  result: CsvAnalysisResult | null; onAnalyze: () => void;
}) {
  return <div className="page-content">
    <div className="back-link"><Link to="/">← Back to dashboard</Link></div>
    <PageIntro eyebrow="ANALYSIS MODULE" title="CSV Analysis" description="Upload a CSV to inspect its structure, missing values, descriptive statistics and chart-ready summaries." action={<span className="badge badge-success">Descriptive analysis available</span>} />
    <div className="module-detail-grid">
      <section className="surface-card upload-panel"><div className="card-title-row"><div><div className="eyebrow">INPUT WORKSPACE</div><h3>Analyze a dataset</h3></div><div className="module-icon teal"><Table2 size={21} /></div></div>
        <p className="muted">CSV files up to 10 MB are processed in memory and are not saved by this endpoint.</p>
        <label className="drop-zone"><input type="file" accept=".csv,text/csv" onChange={(e) => handleFile(e.target.files?.[0])} /><span className="upload-circle"><Upload size={21} /></span><strong>{file ? file.name : "Choose a CSV file"}</strong><span>{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB · ready to upload` : "UTF-8 and common text encodings supported · 10 MB maximum"}</span><span className="button button-secondary button-small">Browse files</span></label>
        {file && <div className="selected-file"><FileText size={18} /><div><strong>{file.name}</strong><span>{(file.size / 1024 / 1024).toFixed(2)} MB</span></div><button className="icon-button" onClick={clearFile} aria-label="Remove selected file"><X size={16} /></button></div>}
        {notice && <div className="inline-notice" role="alert"><CircleHelp size={16} />{notice}</div>}
        <button className="button button-primary full-width" disabled={busy || !file} onClick={onAnalyze}><Table2 size={16} /> {busy ? "Analyzing CSV…" : "Analyze CSV"} <ArrowRight size={15} /></button>
        <p className="privacy-hint"><LockKeyhole size={13} /> Descriptive summaries only. No diagnosis, risk score or medical prediction is produced.</p>
      </section>
      <aside className="module-side-column"><section className="surface-card"><div className="eyebrow">ANALYSIS SCOPE</div><h3>Dataset exploration</h3><p className="muted">Reports dimensions, inferred column types, missingness, numeric summaries and frequent categories for charts.</p><div className="status-row"><span>Upload limit</span><span className="status-value success">10 MB</span></div><div className="status-row"><span>Medical prediction</span><span className="status-value pending">Not performed</span></div><div className="status-row"><span>File persistence</span><span className="status-value success">None</span></div></section><section className="medical-disclaimer"><ShieldCheck size={17} /><div><strong>Descriptive statistics are not diagnosis</strong><p>These summaries describe the uploaded data and must not be used to make clinical decisions.</p></div></section></aside>
    </div>
    {result && <section className="csv-results surface-card" aria-live="polite">
      <div className="table-intro"><div><div className="eyebrow">DESCRIPTIVE RESULTS</div><h3>{result.filename}</h3><p>{result.shape.rows.toLocaleString()} rows · {result.shape.columns} columns · summary only</p></div><span className="badge badge-success">No diagnosis</span></div>
      <h4>Columns and missing values</h4><div className="table-scroll"><table><thead><tr><th>Column</th><th>Type</th><th>Missing</th><th>Missing %</th></tr></thead><tbody>{result.columns.map((col) => <tr key={col.name}><td><strong>{col.name}</strong></td><td>{col.dtype}</td><td>{col.missing.toLocaleString()}</td><td>{col.missing_percent}%</td></tr>)}</tbody></table></div>
      <h4>Numeric descriptive statistics</h4>{result.chart_data.numeric.length ? <div className="table-scroll"><table><thead><tr><th>Column</th><th>Count</th><th>Mean</th><th>Std</th><th>Min</th><th>Median</th><th>Max</th></tr></thead><tbody>{result.chart_data.numeric.map((item) => <tr key={item.column}><td><strong>{item.column}</strong></td><td>{item.count}</td><td>{formatStat(item.mean)}</td><td>{formatStat(item.std)}</td><td>{formatStat(item.min)}</td><td>{formatStat(item.median)}</td><td>{formatStat(item.max)}</td></tr>)}</tbody></table></div> : <p className="muted csv-empty">No numeric columns were detected.</p>}
      {result.chart_data.categorical.length > 0 && <><h4>Chart-ready category counts <small>(top 20 per column)</small></h4><div className="csv-category-grid">{result.chart_data.categorical.map((group) => <div className="csv-category-card" key={group.column}><strong>{group.column}</strong>{group.counts.map((entry) => <div key={entry.label}><span>{entry.label}</span><b>{entry.count}</b></div>)}</div>)}</div></>}
    </section>}
  </div>;
}
function formatStat(value: number | null) { return value === null ? "—" : Number(value.toPrecision(5)).toLocaleString(); }

function ReportWorkflow({ module, file, notice, handleFile, clearFile, busy, result, onExtract }: {
  module: ResearchModule; file: File | null; notice: string; handleFile: (file: File | undefined) => void;
  clearFile: () => void; busy: boolean; result: ReportExtractionResult | null; onExtract: () => void;
}) {
  return <div className="page-content">
    <div className="back-link"><Link to="/">← Back to dashboard</Link></div>
    <PageIntro eyebrow="DOCUMENT WORKFLOW" title={module.title} description="Extract text from a report PDF or image, then review the extracted text yourself." action={<span className="badge badge-success">Text extraction available</span>} />
    <div className="module-detail-grid">
      <section className="surface-card upload-panel"><div className="card-title-row"><div><div className="eyebrow">INPUT WORKSPACE</div><h3>Extract report text</h3></div><div className="module-icon green"><FileText size={21} /></div></div>
        <p className="muted">PDF and image files up to 10 MB. Processing is local; uploaded files are not saved by this endpoint.</p>
        <label className="drop-zone"><input type="file" accept=".pdf,.png,.jpg,.jpeg,.tif,.tiff,.bmp,application/pdf,image/*" onChange={(e) => handleFile(e.target.files?.[0])} /><span className="upload-circle"><Upload size={21} /></span><strong>{file ? file.name : "Choose a report PDF or image"}</strong><span>{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB · ready to upload` : "PDF (up to 20 pages), PNG, JPG, TIFF or BMP · 10 MB maximum"}</span><span className="button button-secondary button-small">Browse files</span></label>
        {file && <div className="selected-file"><FileText size={18} /><div><strong>{file.name}</strong><span>{(file.size / 1024 / 1024).toFixed(2)} MB</span></div><button className="icon-button" onClick={clearFile} aria-label="Remove selected file"><X size={16} /></button></div>}
        {notice && <div className="inline-notice" role="alert"><CircleHelp size={16} />{notice}</div>}
        <button className="button button-primary full-width" disabled={busy || !file} onClick={onExtract}><FileText size={16} /> {busy ? "Extracting text…" : "Extract text"} <ArrowRight size={15} /></button>
        <p className="privacy-hint"><LockKeyhole size={13} /> Text extraction only. No diagnosis, summary, or clinical interpretation is produced.</p>
      </section>
      <aside className="module-side-column"><section className="surface-card"><div className="eyebrow">WHAT THIS DOES</div><h3>Text for your review</h3><p className="muted">Digital PDFs use their embedded text. Scanned PDFs and images use the local Tesseract OCR engine.</p><div className="status-row"><span>Maximum file size</span><span className="status-value success">10 MB</span></div><div className="status-row"><span>Scanned PDF length</span><span className="status-value success">20 pages</span></div><div className="status-row"><span>Medical interpretation</span><span className="status-value pending">Not performed</span></div></section><section className="medical-disclaimer"><ShieldCheck size={17} /><div><strong>Review OCR output carefully</strong><p>OCR can miss or misread text. Confirm extracted content against the original document; do not use it alone for clinical decisions.</p></div></section></aside>
    </div>
    {result && <section className="report-results surface-card" aria-live="polite"><div className="table-intro"><div><div className="eyebrow">EXTRACTED TEXT</div><h3>{result.filename}</h3><p>{result.pages} {result.pages === 1 ? "page" : "pages"} · {result.character_count.toLocaleString()} characters · {result.method === "ocr" ? "OCR" : "embedded PDF text"}</p></div><span className="badge badge-neutral">Review required</span></div><pre className="extracted-report-text">{result.text || "No text was detected in this file."}</pre><div className="table-footnote"><ShieldCheck size={15} /> Text extraction only; the application does not interpret medical meaning or provide diagnosis.</div></section>}
  </div>;
}

function ModelsPage() {
  const rows = [
    ["Histopathology CNN / ResNet", "Tissue images", "Not installed"],
    ["BRCA1 / BRCA2 predictor", "Matched pathology + mutation labels", "Not installed"],
    ["CT-specific model", "Compatible CT series", "Not installed"],
    ["MRI-specific model", "Supported MRI sequences", "Not installed"],
    ["Radiology / mammography model", "Validated intended modality", "Not installed"],
    ["Document text extraction", "PDF / image reports", "Available (Tesseract required for OCR)"],
    ["CSV descriptive analysis", "Tabular datasets", "Available"],
  ];
  return <div className="page-content"><PageIntro eyebrow="RESEARCH TOOLS" title="Model registry" description="Track model readiness and requirements before enabling inference." /><section className="surface-card table-card"><div className="table-intro"><div><h3>Registered model slots</h3><p>Model architectures and checkpoints are not bundled in this Phase 1 foundation.</p></div><span className="badge badge-neutral">0 models installed</span></div><div className="table-scroll"><table><thead><tr><th>Model / processor</th><th>Expected input</th><th>Status</th></tr></thead><tbody>{rows.map((r) => <tr key={r[0]}><td><strong>{r[0]}</strong></td><td>{r[1]}</td><td><span className="status-value pending">{r[2]}</span></td></tr>)}</tbody></table></div><div className="table-footnote"><CircleHelp size={15} /> Install only models with documented task compatibility, provenance, licensing, and evaluation evidence.</div></section><section className="info-banner"><CloudDownload size={20} /><div><strong>Offline-first model policy</strong><p>Model weights can be added locally or downloaded later from authorized sources. The core UI does not require online model services.</p></div></section></div>;
}

function ExperimentResultsPage() {
  const results = [
    { magnification: "40×", accuracy: "77.0%", accuracyRange: "72.1–80.7%", recall: "82.9%", recallRange: "76.7–89.5%", specificity: "65.4%", specificityRange: "43.3–76.6%", balanced: "74.1%" },
    { magnification: "100×", accuracy: "77.2%", accuracyRange: "73.6–80.8%", recall: "83.7%", recallRange: "72.5–92.1%", specificity: "64.4%", specificityRange: "46.9–75.5%", balanced: "74.1%" },
    { magnification: "200×", accuracy: "81.4%", accuracyRange: "75.8–84.5%", recall: "82.9%", recallRange: "70.2–88.8%", specificity: "78.1%", specificityRange: "64.9–86.1%", balanced: "80.5%" },
    { magnification: "400×", accuracy: "81.3%", accuracyRange: "76.9–84.7%", recall: "83.0%", recallRange: "79.2–86.8%", specificity: "78.2%", specificityRange: "71.6–86.6%", balanced: "80.6%" },
  ];

  return <div className="page-content experiment-results-page">
    <PageIntro eyebrow="RESEARCH EVALUATION" title="BreaKHis experiment results" description="Five-fold summary of the research-only ResNet-18 runs across four image magnifications." />
    <section className="medical-disclaimer" aria-label="Research-only notice">
      <ShieldCheck size={18} />
      <div><strong>Research results only — not for diagnosis or clinical decisions</strong><p>This model has not been clinically validated and must not be used to assess patient images.</p></div>
    </section>

    <div className="stat-grid experiment-stat-grid">
      <StatCard icon={<FlaskConical size={19} />} label="Magnifications evaluated" value="4" note="40× · 100× · 200× · 400×" tone="teal" />
      <StatCard icon={<Activity size={19} />} label="Fold-level runs" value="20" note="Five official splits per magnification" tone="blue" />
      <StatCard icon={<BrainCircuit size={19} />} label="Model" value="ResNet-18" note="ImageNet weights; research baseline" tone="purple" />
      <StatCard icon={<ShieldCheck size={19} />} label="External validation" value="Pending" note="BACH use awaits license clarification" tone="orange" />
    </div>

    <section className="surface-card table-card experiment-table-card">
      <div className="table-intro"><div><div className="eyebrow">MEAN FOLD METRICS</div><h3>Magnification comparison</h3><p>Arithmetic mean across five fold-level runs; ranges show minimum to maximum fold results.</p></div><span className="badge badge-neutral">20 runs</span></div>
      <div className="table-scroll"><table className="experiment-table"><thead><tr><th>Magnification</th><th>Accuracy</th><th>Malignant recall</th><th>Benign specificity</th><th>Balanced accuracy</th></tr></thead><tbody>{results.map((row) => <tr key={row.magnification}><td><strong>{row.magnification}</strong></td><td><strong>{row.accuracy}</strong><small>{row.accuracyRange}</small></td><td><strong>{row.recall}</strong><small>{row.recallRange}</small></td><td><strong>{row.specificity}</strong><small>{row.specificityRange}</small></td><td><strong>{row.balanced}</strong></td></tr>)}</tbody></table></div>
      <div className="table-footnote"><CircleHelp size={15} /> Fold test sets overlap. Use mean fold-level metrics; do not interpret their counts as unique cases pooled into one test set.</div>
    </section>

    <div className="results-detail-grid">
      <section className="surface-card"><div className="eyebrow">EXPERIMENT SETUP</div><h3>How these results were produced</h3><div className="results-detail-list"><div><span>Dataset</span><strong>BreaKHis</strong></div><div><span>Task</span><strong>Benign vs malignant image classification</strong></div><div><span>Input size</span><strong>128 × 128 pixels</strong></div><div><span>Training</span><strong>Layer 4 and classifier fine-tuned; early stopping on validation loss</strong></div><div><span>Group separation</span><strong>Fit, validation, and test groups did not overlap within each run</strong></div></div></section>
      <section className="surface-card results-reading-card"><div className="eyebrow">INTERPRETATION</div><h3>200× and 400× were similar</h3><p>Their mean accuracy and specificity were higher than 40× and 100× in this experiment, but these results do not establish a reliable winning magnification. Fold results varied, and no confidence intervals were calculated.</p><p>The BACH external evaluation has not been run while its license terms are being clarified.</p><Link to="/models" className="text-link">Review model readiness <ArrowRight size={15} /></Link></section>
    </div>
  </div>;
}

function HistoryPage() { return <div className="page-content"><PageIntro eyebrow="RESEARCH RECORDS" title="Analysis history" description="Your future analyses will be recorded here with model and input provenance." /><div className="empty-state surface-card"><div className="empty-state-icon"><ClipboardList size={27} /></div><h3>No saved analyses</h3><p>CSV summaries and extracted report text are returned for the current session and are not saved to analysis history. Image analysis pipelines remain unimplemented.</p><Link to="/" className="button button-primary">Explore modules <ArrowRight size={15} /></Link></div></div>; }
function SettingsPage() { return <div className="page-content"><PageIntro eyebrow="PREFERENCES" title="Settings" description="Local environment and project configuration." /><div className="settings-grid"><section className="surface-card"><div className="card-title-row"><h3>Runtime</h3><Zap size={19} /></div><div className="settings-row"><div><strong>Execution mode</strong><p>CPU-first with optional GPU acceleration in future model integrations.</p></div><span className="badge badge-success">CPU-first</span></div><div className="settings-row"><div><strong>Connectivity</strong><p>Core interface and API are designed for local operation after installation.</p></div><span className="badge badge-success">Local</span></div></section><section className="surface-card"><div className="card-title-row"><h3>Account</h3><UserRound size={19} /></div><p className="muted">Registration and login API endpoints are available. The frontend account forms and protected page flows are not yet connected in this phase.</p><Link className="text-link" to="/login">Open authentication preview <ArrowRight size={15} /></Link></section></div></div>; }
function AuthPage() {
  const [mode, setMode] = useState<"login" | "register">("register");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      if (mode === "register") {
        const response = await fetch(`${API_BASE}/api/auth/register`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, username, password }) });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail ?? "Registration failed");
        setMessage("Account created. You can now sign in.");
        setMode("login");
      } else {
        const response = await fetch(`${API_BASE}/api/auth/login`, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ username: username || email, password }) });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail ?? "Login failed");
        localStorage.setItem("breastcare_access_token", data.access_token);
        setMessage("Signed in. This foundation stores the token locally; protected dashboard flows will be completed in a later phase.");
        setTimeout(() => navigate("/"), 700);
      }
    } catch (err) { setMessage(err instanceof Error ? err.message : "Request failed"); }
    finally { setBusy(false); }
  }
  return <div className="auth-wrap"><section className="auth-card surface-card"><div className="auth-brand"><Brand /></div><div className="eyebrow">LOCAL RESEARCH ACCOUNT</div><h1>{mode === "register" ? "Create your account" : "Welcome back"}</h1><p className="muted">Account access for your local BreastCare AI workspace.</p><div className="auth-tabs"><button className={mode === "register" ? "selected" : ""} onClick={() => { setMode("register"); setMessage(""); }}>Register</button><button className={mode === "login" ? "selected" : ""} onClick={() => { setMode("login"); setMessage(""); }}>Sign in</button></div><form onSubmit={submit} className="auth-form">{mode === "register" && <div className="form-field"><label>Email</label><input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" /></div>}{mode === "login" && <div className="form-field"><label>Email or username</label><input required value={username || email} onChange={(e) => { setUsername(e.target.value); setEmail(e.target.value); }} placeholder="Enter email or username" /></div>}{mode === "register" && <div className="form-field"><label>Username</label><input required minLength={3} value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Choose a username" /></div>}<div className="form-field"><label>Password</label><input type="password" required minLength={mode === "register" ? 10 : 1} value={password} onChange={(e) => setPassword(e.target.value)} placeholder={mode === "register" ? "At least 10 characters" : "Your password"} /></div><button className="button button-primary full-width" disabled={busy}>{busy ? "Please wait…" : mode === "register" ? "Create account" : "Sign in"} <ArrowRight size={15} /></button>{message && <div className="inline-notice">{message}</div>}</form><p className="privacy-hint"><LockKeyhole size={13} /> Use only a local development environment. Configure a strong secret before any shared deployment.</p></section></div>;
}
function NotFound() { return <div className="empty-state surface-card"><h2>Page not found</h2><p>The page you requested does not exist.</p><Link className="button button-primary" to="/">Return to dashboard</Link></div>; }

export default App;
