export type ModuleStatus =
  | "interface_ready_model_missing"
  | "interface_ready_text_extraction"
  | "interface_ready_descriptive_analysis"
  | "interface_ready_processing_not_implemented";

export interface ResearchModule {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  icon: string;
  input_types: string[];
  status: ModuleStatus;
  accent: string;
}
