import type { ResearchModule } from "./types";

export const API_BASE = import.meta.env.VITE_API_BASE_URL ?? "http://127.0.0.1:8000";

export async function getHealth() {
  const response = await fetch(`${API_BASE}/api/health`);
  if (!response.ok) throw new Error("Backend health check failed");
  return response.json() as Promise<{ status: string; app: string; phase: string | number }>;
}

export async function getModules() {
  const response = await fetch(`${API_BASE}/api/modules`);
  if (!response.ok) throw new Error("Could not load modules");
  const data = await response.json();
  return data.modules as ResearchModule[];
}

export async function analyzeCsv(file: File): Promise<CsvAnalysisResult> {
  const body = new FormData();
  body.append("file", file);
  const response = await fetch(`${API_BASE}/api/csv/analyze`, { method: "POST", body });
  const data = await response.json();
  if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : "CSV analysis failed.");
  return data as CsvAnalysisResult;
}

export async function extractReport(file: File): Promise<ReportExtractionResult> {
  const body = new FormData();
  body.append("file", file);
  const response = await fetch(`${API_BASE}/api/reports/extract`, { method: "POST", body });
  const data = await response.json();
  if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : "Text extraction failed.");
  return data as ReportExtractionResult;
}

export interface ReportExtractionResult {
  filename: string;
  size_bytes: number;
  extraction_type: string;
  character_count: number;
  method: "ocr" | "embedded_text";
  pages: number;
  text: string;
}

export interface CsvAnalysisResult {
  filename: string;
  size_bytes: number;
  analysis_type: string;
  shape: { rows: number; columns: number };
  columns: { name: string; dtype: string; missing: number; missing_percent: number }[];
  descriptive_statistics: Record<string, Record<string, number | null>>;
  chart_data: {
    numeric: { column: string; count: number; mean: number | null; std: number | null; min: number | null; q25: number | null; median: number | null; q75: number | null; max: number | null }[];
    categorical: { column: string; counts: { label: string; count: number }[] }[];
  };
}
