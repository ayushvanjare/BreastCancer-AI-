# BreastCare AI — Phase 2.2 Research Project

## Abstract

BreastCare AI is a local-first research software foundation for exploring breast-cancer-related datasets. Phase 2.2 provides a React dashboard with six analysis workflows, a FastAPI backend, descriptive CSV analysis, and local text extraction from doctor-report PDFs and images. A separate research experiment evaluated an ImageNet-pretrained ResNet-18 on BreaKHis histopathology images at four magnifications. The dashboard displays the experiment results as static metrics only. The software does not diagnose cancer, and the model has not been clinically validated.

## Project objectives

- Provide one local workspace for several breast-cancer research data workflows.
- Support descriptive CSV exploration and report-text extraction.
- Establish a reproducible, research-only histopathology image-classification baseline.
- Present model results with clear limits and avoid clinical inference.

## Implemented software

- React, TypeScript, and Vite dashboard with module navigation, model registry, history, settings, and an Experiment Results page.
- FastAPI backend exposing health, module, authentication, CSV-analysis, and report-extraction endpoints.
- CSV analysis: accepts files up to 10 MB, reports shape, columns, inferred data types, missing values, descriptive statistics, and chart-ready category counts. Uploaded files are analyzed in memory and are not persisted.
- Doctor Reports: extracts embedded PDF text or uses local Tesseract OCR for scanned PDFs and images. Uploads are limited to 10 MB and PDFs to 20 pages. Extracted text is for human review and is not interpreted.
- Image-analysis module pages remain previews. No trained medical model weights are installed in the dashboard and no image predictions are available.

## BreaKHis experiment method

- Dataset: BreaKHis histopathology images with benign and malignant labels.
- Model: ImageNet-pretrained ResNet-18; early layers frozen while layer 4 and the classifier were fine-tuned.
- Each magnification (40X, 100X, 200X, 400X) was evaluated separately at 128 × 128 pixels.
- Five official fold splits were used per magnification. A group-separated validation subset was selected from each fold’s training split. The official test split was held out.
- Training used a maximum of 8 epochs with early stopping based on validation loss (patience 2).
- The RTX 3050 CUDA environment was used. Every run reported zero shared sample groups between fit, validation, and test partitions.
- Reported values below are arithmetic means of fold-level metrics. The fold test sets overlap, so they are not pooled as if they were distinct images.

## Results

| Magnification | Mean accuracy | Mean malignant recall | Mean benign specificity | Mean balanced accuracy |
|---|---:|---:|---:|---:|
| 40X | 77.0% | 82.9% | 65.4% | 74.1% |
| 100X | 77.2% | 83.7% | 64.4% | 74.1% |
| 200X | 81.4% | 82.9% | 78.1% | 80.5% |
| 400X | 81.3% | 83.0% | 78.2% | 80.6% |

In this experiment, 200X and 400X had similar averages and higher mean specificity than 40X and 100X. The results do not establish a reliable winning magnification; fold-level variation was material. The detailed fold ranges and additional notes are in `BREAKHIS_EXPERIMENT_SUMMARY.md`.

## Verification

The project owner confirmed that the frontend loads the Experiment Results page, the FastAPI `/docs` page opens, and the CSV Analysis and Doctor Reports workflows work locally. These are software checks only; they do not validate medical performance.

## Limitations and responsible use

- This is an exploratory baseline using one public dataset and one random seed. No confidence intervals or external validation results are available.
- Performance on BreaKHis does not establish performance at other hospitals, scanners, staining conditions, or patient populations.
- BACH images were downloaded and their folder structure was inspected, but model evaluation has not been performed. The dataset’s CC BY-NC-ND license says images cannot be changed; permission clarification was requested before preprocessing.
- Do not use the model or these metrics for diagnosis, screening, triage, treatment, or other patient-care decisions. Do not enable patient-image inference in the dashboard.

## How to run locally on Windows

Start the backend in one PowerShell terminal:

```powershell
Set-Location "$env:USERPROFILE\Downloads\BreastCare_AI_Phase2_2\backend"
& ".\.venv\Scripts\python.exe" -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Start the frontend in a second terminal:

```powershell
Set-Location "$env:USERPROFILE\Downloads\BreastCare_AI_Phase2_2\frontend"
npm run dev
```

Open `http://localhost:5173`. The Experiment Results page is at `http://localhost:5173/results`. Backend API documentation is at `http://127.0.0.1:8000/docs`.

## References

1. Spanhol, F. A., Oliveira, L. S., Petitjean, C., and Heutte, L. “A Dataset for Breast Cancer Histopathological Image Classification.” *IEEE Transactions on Biomedical Engineering*, 2016. DOI: 10.1109/TBME.2015.2496264.
2. BreaKHis dataset and download information: https://web.inf.ufpr.br/vri/databases/breast-cancer-histopathological-database-breakhis/
