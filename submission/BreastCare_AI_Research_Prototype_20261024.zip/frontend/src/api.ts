import type { ResearchModule } from "./types";

export const API_BASE = import.meta.env.VITE_API_BASE_URL ?? "http://127.0.0.1:8000";

export async function getHealth() {
  const response = await fetch(`${API_BASE}/api/health`);
  if (!response.ok) throw new Error("Backend health check failed");
  return response.json() as Promise<{ status: string; app: string; phase: string | number }>;
}

export async function getModules() {
  const response = await fetch(`${API_BASE}/api/modules`);
  if (!response.ok) throw new Error("Could not load modules");
  const data = await response.json();
  return data.modules as ResearchModule[];
}

export async function analyzeCsv(file: File): Promise<CsvAnalysisResult> {
  const body = new FormData();
  body.append("file", file);
  const response = await fetch(`${API_BASE}/api/csv/analyze`, { method: "POST", body });
  const data = await response.json();
  if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : "CSV analysis failed.");
  return data as CsvAnalysisResult;
}

export async function extractReport(file: File): Promise<ReportExtractionResult> {
  const body = new FormData();
  body.append("file", file);
  const response = await fetch(`${API_BASE}/api/reports/extract`, { method: "POST", body });
  const data = await response.json();
  if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : "Text extraction failed.");
  return data as ReportExtractionResult;
}

export async function predictHistopathology(file: File, includeGradCam: boolean): Promise<HistopathologyResult> {
  const body = new FormData();
  body.append("file", file);
  body.append("explain", String(includeGradCam));
  const response = await fetch(`${API_BASE}/api/research/histopathology/predict`, { method: "POST", body });
  const data = await response.json();
  if (!response.ok) {
    const detail = data.detail;
    throw new Error(typeof detail === "string" ? detail : detail?.message ?? "Research model could not process this image.");
  }
  return data as HistopathologyResult;
}

export interface HistopathologyResult {
  filename: string;
  size_bytes: number;
  analysis_type: "research_only_model_output";
  research_only: true;
  predicted_class: "benign" | "malignant";
  class_scores: { benign: number; malignant: number };
  score_note: string;
  model: string;
  training_fold: string;
  training_magnification: string;
  image_size: number;
  execution_device: string;
  clinical_use: false;
  explanation?: string;
  grad_cam_overlay_png_base64?: string;
}

export async function inspectImaging(moduleId: "ct" | "mri" | "xray", file: File): Promise<ImagingInspectionResult> {
  const body = new FormData();
  body.append("module_id", moduleId);
  body.append("file", file);
  const response = await fetch(`${API_BASE}/api/imaging/inspect`, { method: "POST", body });
  const data = await response.json();
  if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : "The image could not be inspected.");
  return data as ImagingInspectionResult;
}

export interface ImagingInspectionResult {
  filename: string;
  size_bytes: number;
  inspection_type: "raster_image_metadata" | "dicom_header_metadata";
  module_id: "ct" | "mri" | "xray";
  modality_check: "not_verifiable_from_raster_image" | "matches_selected_module";
  metadata: {
    format?: string;
    width?: number;
    height?: number;
    mode?: string;
    modality?: string;
    rows?: number | null;
    columns?: number | null;
    frames?: number | null;
    samples_per_pixel?: number | null;
    pixel_spacing_mm?: number[] | null;
    slice_thickness_mm?: number[] | null;
  };
  patient_identifiers_returned: false;
  model_inference_performed: false;
  note?: string;
}

export interface ReportExtractionResult {
  filename: string;
  size_bytes: number;
  extraction_type: string;
  character_count: number;
  method: "ocr" | "embedded_text";
  pages: number;
  text: string;
}

export interface CsvAnalysisResult {
  filename: string;
  size_bytes: number;
  analysis_type: string;
  shape: { rows: number; columns: number };
  columns: { name: string; dtype: string; missing: number; missing_percent: number }[];
  descriptive_statistics: Record<string, Record<string, number | null>>;
  chart_data: {
    numeric: { column: string; count: number; mean: number | null; std: number | null; min: number | null; q25: number | null; median: number | null; q75: number | null; max: number | null }[];
    categorical: { column: string; counts: { label: string; count: number }[] }[];
  };
}
